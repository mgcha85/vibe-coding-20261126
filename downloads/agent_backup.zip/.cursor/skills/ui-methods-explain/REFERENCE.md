# Methods visualization reference

`/methods` 설명 시각화의 SSOT. 구현·에이전트용. **웹 UI 카피에 이 문서의 스택/C4 용어를 그대로 옮기지 말 것.**

## 목적

결과 차트(QC·UMAP·마커)와 분리된 **방법 설명** 층이다.

1. 경계: 누가 결과를 보고, 무엇을 입력으로 쓰는지
2. 흐름: 입력 → 계산 → 저장 → 화면
3. 순서: 단계별 방법·고정 기준
4. 양: 세포가 왜·얼마나 줄었는지
5. 시간: 실행하면 무엇이 어떤 순서로 일어나는지

## 뷰 ↔ 컴포넌트

| 뷰 (방문객 제목) | 컴포넌트 | 구현 메모 |
| --- | --- | --- |
| 누가 무엇을 보나 | `MethodsC4Context.astro` | 스토리: 연구자(사람 아이콘) → 공개 데이터 → 분석 → 결과. 아이콘 `assets/icons/methods/` |
| 데이터가 어떻게 흐르나 | `MethodsC4Containers.astro` | C4 L2 **구조**만. 박스에 DuckDB/Astro/경로 금지 |
| 알고리즘을 그림으로 | `MethodsAlgoIcons.astro` | `src/assets/icons/algo/*.svg` + 한국어 한 줄. 카탈로그: `ui-chrome` |
| 분석 순서 | `MethodsPipelineSchematic.astro` | 세로 번호 카드. ECharts graph/DAG 금지 |
| 세포 수 변화 | `MethodsCellFunnel.astro` | HTML/CSS 막대 퍼널. ECharts sankey 금지 |
| 실행하면… | `MethodsRuntimeTimeline.astro` | 세로 스토리보드. Mermaid sequence 금지 |
| 단계 상세 | `pages/methods/[stage].astro` | `methods_pipeline.json` 스테이지 필드 |

결과 플롯(분포·UMAP·dot/violin)은 **ECharts only** (`ui-echarts`, `ui-viz-*`). Methods 보드에는 ECharts를 쓰지 않는다.

## 왜 이 형태인가

| 피한 것 | 이유 | 대신 |
| --- | --- | --- |
| Mermaid flowchart / sequence | 기본 테마·레이아웃이 문서 덤프처럼 보임 | 시맨틱 HTML + CSS |
| 원형 노드 + 화살표 “DAG” | 단계 의미·파라미터가 안 보임 | 번호 스키매틱 카드 |
| Sankey | 리본이 이유를 설명하지 못함 | 제외 사유가 적힌 퍼널 막대 |
| 스택 콜아웃 | 연구자 페이지에 엔지니어링 홍보가 됨 | skills에만 스택 |

## 카피 체크리스트 (페이지 배포 전)

- [ ] “C4”, “Context”, “Containers”, “Level”, “다음 장” 없음
- [ ] DuckDB / Polars / Astro / ECharts / pandas / SSOT / warehouse 경로 없음
- [ ] `.venv`, `backend.*`, `public/data`, `data/raw/*.h5ad` 화면 노출 없음
- [ ] “Sankey/Mermaid/UML 대신 …” 변명 문장 없음
- [ ] 수치(`metrics`/`funnel`)는 JSON에서 오고 하드코딩 아님

## 데이터 계약

`methods_pipeline.json` (export 병합):

- `stages[]`: `id`, `title_ko`, `algorithms[]`, `why`, `inputs[]`, `outputs[]`, `params`, `pseudo[]`, `refs[]`, `result_route`
- `metrics`: `n_cells_raw`, `n_cells_filtered`, `n_genes*`, `n_clusters`, …
- `funnel[]`: 단계별 실측 (QC 제외 사유 포함)

문구 원본: `backend/common/methods_meta.py` — **방문객용 한국어**로 유지. `command` 필드는 export/재현용이며 UI에 렌더하지 않는다.

## 스타일 힌트

- 보드 배경: 옅은 radial / elevated surface, 카드 남발 금지
- person 노드는 둥근 상단, system은 실선, external/입력은 dashed
- 퍼널 색: 시작(청) → 제외(적) → 통과(녹) → 무리(청록)
- 타임라인: accent 점 + 가는 세로 레일

## 관련

- `ui-echarts` — 결과 차트만
- `ui-astro-app` — 라우트·`public/data`만 읽기
- `data-analytics-export` — JSON 생성
- `AGENTS.md` § Stack — 구현 스택(화면 카피 아님)
