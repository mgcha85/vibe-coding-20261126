---
name: ui-methods-explain
description: Builds /methods explain pages — who/what board, data-flow board, pipeline schematic, cell funnel, runtime timeline. Visitor copy must stay plain-language. Use when editing /methods or methods explain UX. Result charts use ui-viz-*; ECharts rules use ui-echarts. Full viz rules in REFERENCE.md.
---

# UI Methods Explain

보는 사람이 **누가 무엇을 보는지 → 데이터가 어떻게 흐르는지 → 분석 순서 → 세포가 줄어드는 이유 → 실행 순서**를 읽게 한다.

상세 시각화 규칙·금지 카피 → [REFERENCE.md](REFERENCE.md)

## Routes

- `/methods` — who/what, data flow, **algorithm SVG icons**, pipeline schematic, cell funnel, runtime timeline
- `/methods/[stage]` — why / methods / I/O / params / steps / measured facts / refs / result link

## Copy rule (강제)

웹페이지에 쓰지 말 것:

- C4 레벨명·다이어그램 용어 (`C4`, `Context`, `Containers`, `Level 1`, `다음 장…`)
- 구현 스택·도구 홍보 (`DuckDB`, `Polars`, `Astro`, `ECharts`, `pandas 금지`, `SSOT`, `warehouse` 경로)
- 저장소 경로·모듈 명령 (`.venv`, `backend.*`, `public/data/*.json`, `data/raw/…`)
- 차트 변명 (`Sankey 대신`, `Mermaid 대신`, `UML 대신`)

그런 내용은 **skills / AGENTS / 코드 주석**에만 둔다. 화면은 연구자 한국어.

## Visual language (do / don't)

| View | Do | Don't |
| --- | --- | --- |
| Who / what | **연구자 → 공개 데이터 → 분석 → 결과** 스토리 보드 + 사람/데이터 SVG 아이콘 | C4 person↔system↔external 양방향, Mermaid |
| Data flow | 입력→계산→저장→화면 박스 | 스택·파일경로 나열 |
| Algorithms | SVG 아이콘 + 한 줄 설명 (`MethodsAlgoIcons`, assets in `icons/algo/`) | 텍스트만 / 스택 로고 |
| Pipeline | 번호 카드 + 방법 칩 + 핵심 기준 | 원형 노드 DAG만 |
| Cell counts | 퍼널 스토리: 시작→제외 이유→통과→무리, 막대 폭∝수 | 라벨 없는 Sankey |
| Runtime | 세로 타임라인 | Mermaid sequenceDiagram |

## Data

- `frontend/public/data/methods_pipeline.json` ← `backend.export` + `methods_meta.py`
- 세포 수는 Astro에 하드코딩 금지 → `metrics` / `funnel`
- `methods_meta.STAGES` 문구도 방문객용으로 유지 (export가 페이지에 그대로 나감)

## Components

- `MethodsC4Context.astro` — 파일명 legacy; UI 제목은 「누가 무엇을 보나」
- `MethodsC4Containers.astro` — UI 제목 「데이터가 어떻게 흐르나」
- `MethodsAlgoIcons.astro` — 알고리즘 SVG 설명 (`ui-chrome` asset catalog)
- `MethodsPipelineSchematic.astro`
- `MethodsCellFunnel.astro`
- `MethodsRuntimeTimeline.astro`
