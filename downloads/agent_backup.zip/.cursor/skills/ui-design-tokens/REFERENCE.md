# Design Tokens Reference

## Cluster categorical palette (colorblind-aware-ish)

Use for Leiden coloring; cycle if >9 clusters.

```css
:root {
  --cluster-0: #1b9e77;
  --cluster-1: #d95f02;
  --cluster-2: #7570b3;
  --cluster-3: #e7298a;
  --cluster-4: #66a61e;
  --cluster-5: #e6ab02;
  --cluster-6: #a6761d;
  --cluster-7: #666666;
  --cluster-8: #1f78b4;
}
```

## Viz tokens

```css
:root {
  --viz-axis: var(--color-text-muted);
  --viz-grid: #e2e8f0;
  --viz-tooltip-bg: #ffffff;
  --viz-tooltip-border: var(--color-border);
  --viz-point-opacity: 0.85;
  --viz-point-radius: 3px;
}
```

## Elevation

Light UI: prefer border over heavy shadow.

```css
:root {
  --shadow-sm: 0 1px 2px rgb(15 23 42 / 6%);
}
```
