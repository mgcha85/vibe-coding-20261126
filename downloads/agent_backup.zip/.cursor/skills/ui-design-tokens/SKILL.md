---
name: ui-design-tokens
description: Defines CSS design tokens for the Astro lab UI (light-first). Use when editing colors, spacing, type, elevation variables, or tokens.css. Adapted from Owl-Listener designer-skills design-token + color-system. For chart ramps use ui-color-system; for layout use ui-layout-grid.
---

# UI Design Tokens

기반: [Owl-Listener/designer-skills](https://github.com/Owl-Listener/designer-skills) `design-token` / `color-system`. **기본은 light background.**

## Token tiers

1. Global raw (`--blue-600`, `--slate-100`, …)
2. Alias semantic (`--color-bg`, `--color-text`, `--color-border`, `--color-accent`)
3. Component (`--viz-axis`, `--viz-grid`, `--cluster-0` …)

Components never hardcode hex; alias/component tokens만 사용.

## Light defaults (required)

```css
:root {
  --color-bg: #f8fafc;          /* slate-50 */
  --color-bg-elevated: #ffffff;
  --color-text: #0f172a;        /* slate-900 */
  --color-text-muted: #64748b;  /* slate-500 */
  --color-border: #e2e8f0;      /* slate-200 */
  --color-accent: #0369a1;      /* sky-700 — not purple-default */
  --color-danger: #e11d48;
  --color-success: #059669;
  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px;
  --radius-sm: 6px; --radius-md: 10px;
  --font-sans: "Pretendard", "IBM Plex Sans KR", system-ui, sans-serif;
  --font-mono: "IBM Plex Mono", ui-monospace, monospace;
}
```

Avoid AI-default purple-on-white and cream+terracotta clichés. Dark mode는 선택 옵트인; 기본 구현 금지.

전체 스케일·클러스터 팔레트는 [REFERENCE.md](REFERENCE.md).
