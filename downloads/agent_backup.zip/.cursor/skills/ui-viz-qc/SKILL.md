---
name: ui-viz-qc
description: Astro QC visualizations for mitochondrial percentage and gene counts via Apache ECharts. Use when building /qc page charts. For ECharts rules use ui-echarts; for QC backend use data-analytics-qc.
---

# UI Viz QC

**Chart library: Apache ECharts only** (`ui-echarts`).

## Required views

1. **MT% distribution** — ECharts `bar` histogram of `pct_counts_mt` with `markLine` at **5**
2. **Genes per cell** — ECharts `bar` histogram with `markLine` at **200** and **2500**
3. **Summary strip** — cells before/after filter (from `qc_summary.json`, not a chart)

## Encoding

- Light bg; colors from CSS variables via `echarts-setup`
- **Histogram**: bin counts on a **category** x-axis with wide bars (`barWidth` ~90%, small `barCategoryGap`). Do **not** use `xAxis: value` + sparse `[x,y]` bars — that renders thin “stick” bars.
- Thresholds as dashed `markLine` on the nearest category; bars past the fail threshold may use danger color

## Data

`public/data/qc_summary.json`, `qc_cells.json` (per-cell metrics → client-side binning)

## Anti-patterns

- Value-axis bar series with one skinny bar per bin center
- Hand-rolled SVG histograms; static matplotlib PNG as the page body
- One bar per cell (2700 sticks) — always aggregate into bins first
