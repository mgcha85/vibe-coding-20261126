---
name: data-analytics-markers
description: Differential expression and canonical marker panels for Leiden clusters. Use when running rank_genes_groups, writing markers tables, or preparing dot/violin data. For plots use ui-viz-dotplot and ui-viz-violin; for cell-type labels use data-analytics-celltype.
---

# Data Analytics Markers

## DEG

- `sc.tl.rank_genes_groups(groupby="leiden", method="wilcoxon", use_raw=True)`
- Top 10 per cluster → DuckDB `markers`
- Columns: leiden, gene_symbol, scores, logfoldchanges, pvals, pvals_adj, rank

## Canonical panel means

Genes (order fixed):

`IL7R, CD3D, CD3E, CD8A, CD8B, MS4A1, CD79A, CD14, LYZ, S100A8, FCGR3A, MS4A7, GNLY, NKG7, FCER1A, CST3, PPBP`

- Expression source: log-normalized raw layer (scanpy `.raw`)
- Aggregate mean per leiden → `marker_means`
- Missing genes → `results/missing_markers.json` (empty list if none)

## Viz handoff

Export JSON for Astro ECharts pages; do not treat PNG as deliverable. Use `ui-viz-dotplot` + `ui-viz-violin` (Apache ECharts only, see `ui-echarts`).
