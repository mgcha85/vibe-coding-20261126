---
name: ui-layout-grid
description: Responsive layout grid for Astro analysis pages. Use when structuring page chrome, main viz stage, and side legends. Adapted from Owl-Listener designer-skills layout-grid. For components spacing use ui-design-tokens.
---

# UI Layout Grid

Adapted from designer-skills `layout-grid`.

## Breakpoints

- 375 / 768 / 1024 / 1440

## Columns

- Mobile 4 · Tablet 8 · Desktop 12
- Gutter 16–24px · Margin 16 (mobile) / 32–48 (desktop)

## Analysis page pattern

```
[ thin header nav ]
[ title + one-line context ]
[ full-bleed viz stage ]     ← primary
[ optional legend / table ]  ← secondary, not competing hero cards
[ footer ]                   ← ui-chrome, pinned via flex
```

## Rules

1. One job per page (QC or UMAP or Markers…).
2. Viz stage is the dominant plane — not a small inset card.
3. No dashboard card grids in the first viewport.
4. Sidebar legend allowed on desktop; collapses below on mobile.
