---
name: blueprint-ragas-eval
description: Flowise/Keylook RAG 품질을 RAGAS-style(F/AR/CR)로 측정·해석하는 공통 절차. stub vs live, judge 모델, full-chunk, year boost, hang/pacing, rejudge 분리. RAGAS·faithfulness·대화품질 평가 시 사용.
---

# RAGAS eval (공통)

Flowise Agent + Keylook 검색 품질을 **reference-free**로 본다.  
메트릭: **faithfulness (F)** / **answer_relevancy (AR)** / **context_relevancy (CR)**.

프로젝트 전용 프롬프트(예: 특정 IR Agent의 FX 문구)는 이 스킬 범위 밖 — **Canvas/Oracle 패치**로 두고, 여기엔 **재사용 가능한 평가·파이프라인 규칙**만.

**템플릿 SoT:** mapped Agent는 git `flows/*.json` + deploy `import-flows` (marketplace 카드와 동기). Canvas 클론 중 `FLOW_MAPPINGS` 밖 UUID는 import가 안 덮음 → **코드 배포**로 full-chunk/year/rerank timeout 적용. BMW FX 등 도메인 프롬프트는 표준 템플릿에 넣지 말 것.

상세 명령·법무 예제: `scripts/README-blueprint-ragas-eval.md`  
시행착오: `LESSON_AND_LEARN.md` (키워드 `ragas`, `full-chunk`, `rerank timeout`)

---

## 언제 이 스킬인가

- QA 세트에 대해 F/AR/CR을 재거나 “검색이 문제인지 / 생성인지 / judge인지”를 가를 때
- preview truncate, collection 불일치, live 504/hang 후 재평가할 때
- 새 Agent/문서군에 RAGAS 하네스를 붙일 때

---

## 평가 계층 (항상 이 순서로)

| 단계 | 무엇을 보나 | 방법 |
|------|-------------|------|
| **R0 검색** | origin/collection/filter, raw vs snippet anchor hit, refuse | Keylook only / `--skip-llm` stub |
| **R1 전달** | Agent가 받는 컨텍스트가 **전문**인지 | preview 길이 금지; Agent=full, rerank API만 clamp |
| **R2 생성** | live Agent 답 | `--live-agent` + 실제 chatflow id |
| **R3 Judge** | F/AR/CR | 전용 judge 모델 · CTX packing · 필요 시 `--rejudge-from` |

**금지:** stub 답(컨텍스트 앞 N자)의 F/AR로 “대화품질 개선됨” 판정. stub는 **검색/전달** 검증용.

---

## 고정 SoT / 환경

1. **Collection·Filter·ENV**를 QA 메타와 맞출 것.  
   - 재현 채널 = 문서가 있는 vDB (`…-vDB-prod` 문서면 `ENV_TYPE/APP_ENV=prod`로 테스트).  
   - Filter/origin을 “비슷해 보이는” 다른 Teams ID로 바꾸지 말 것.
2. **Judge ≠ 챗 모델.**  
   - 기본: `RAGAS_JUDGE_MODEL=Qwen3.5-122B-A10B` (+ `LLM_BASE_URL` …`/v1`, not `/token/v1`).  
   - `.env`의 서비스 챗 모델(예: BIN*)을 judge로 쓰지 말 것.
3. **Synonym 하드코딩을 Flowise에 넣지 말 것** (동의어 SoT는 ARF).  
   연도/회계기간 확장은 **결정적 query expand + soft prefer**로 (예: `26년`→`2026`/`Q1 2026`).

---

## Full chunk 규칙 (공통 파이프라인)

| 구간 | 규칙 |
|------|------|
- Agent / format entry | **전문 우선**. `AGENT_DOC_MAX_CHARS`(기본 24k)·`AGENT_CONTEXT_MAX_CHARS`(기본 90k)로 **토큰 안전 상한**만 — UI preview(1200) 재도입 금지. 초과 시 query-biased window.
| Rerank HTTP API | 페이로드만 `RERANK_API_MAX_CHARS`(기본 7000) clamp. |
| Rerank fetch | **`AbortSignal.timeout`** (`RERANK_TIMEOUT_MS`, 기본 30s). 무한 대기는 event-loop wedge 유발. |

`contentPreviewLength` 노드 입력·플로우 키 재도입 금지.

---

## Live Agent RAGAS 절차

```text
1) ENV + collection/filter QA 메타 일치 확인
2) Flowise ping (외부 ingress + 가능하면 호스트 local :PORT)
3) smoke 2~3 Q live
4) full set: pacing + ping watchdog
5) summary F/AR/CR · refuse · raw/snippet hit
6) 이상 시: hang-diag → restart → 이어서 / 또는 --rejudge-from
```

### Pacing / hang

- `RAGAS_LIVE_PACING_SEC` 기본 **12** (ingress 60s 504·재검색/rerank 부하 완화).
- Prediction 전후 **`/api/v1/ping`**. dead면 diag + hard restart 후 재시도.
- 외부 **nginx 504 ≈ 60s**는 upstream hang 증상. `PREDICTION_TIMEOUT_MS`는 **event loop가 막히면 안 먹음**.
- 도구: `scripts/flowise-hang-diag.sh`, `scripts/restart-flowise-prod-ssh.sh` (OPS SSH; 채널은 `PROJECT.md`).

### 스크립트 맵

| 용도 | 스크립트 |
|------|----------|
| 법무 QA (문서 multi-id) | `scripts/eval-legal-guideline-ragas.py` |
| IR/일반 Keylook+live | `scripts/eval-bmw-ir-ragas.py` (`--live-agent`, `--rejudge-from`, year expand) |
| Setup 메모 | `scripts/README-blueprint-ragas-eval.md` |

새 도메인 QA를 붙일 때: **같은 메트릭·judge·full-chunk·live pacing**을 재사용하고, 도메인 프롬프트만 Canvas에 둔다.

---

## Judge 해석 규칙

| 관찰 | 해석 |
|------|------|
| refuse↓ · snippet≡raw · F/AR 낮음 + stub | **검색 OK, 생성 미평가** → live 필요 |
| live F 낮음 · rejudge 후 F↑ | **judge packing/규칙** 문제였음 (답은 유지) |
| live+rejudge 후에도 F 낮음 | **생성** (환각·FX·창작 분해) 또는 CTX miss |
| CR만 낮음 | 검색/필터/collection/연도 미스 |
| F만 깎임 + 답에 환율/원화 | Canvas에 **상충 규칙**(예: “반드시 KRW 병기”) 있는지 먼저  Grep — 도메인 금지보다 셀 수 있음 |

`--rejudge-from`: **답을 고정**하고 judge/CTX만 바꿔 재채점. 파이프라인 vs 프롬프트 개선을 분리할 때 필수.

Judge CTX:

- year-boosted Keylook hit 우선
- must_include / anchor **pin**
- 과도한 hard penalty(예: KRW만 보고 F=0) 지양 — soft note

---

## 체크리스트 (매 런)

- [ ] Judge = Qwen(또는 명시된 judge), 챗 모델 아님
- [ ] collection / filter / `ENV_TYPE` = QA SoT
- [ ] synonym Flowise 하드코딩 없음
- [ ] Agent full chunk · rerank API clamp only · rerank timeout on
- [ ] stub로 F 개선 주장하지 않음
- [ ] live면 pacing ≥ 12s + ping watchdog
- [ ] 결과 JSON/xlsx 경로·n·refuse·F/AR/CR 기록
- [ ] 도메인 전용 프롬프트 변경은 Canvas/패처에만 (이 스킬에 복붙 금지)

---

## 배포 주의

- 평가용으로 `:32395` 등을 `ENV_TYPE=prod`로 올린 뒤 **끝나면 채널 복귀 여부 사용자 확인**.
- 코드 반영은 `infra-deploy-runner-github` / `docs/배포방법.md`. 평가 중 우발 `git push`→dev 전환에 주의.
- 런타임 dist 핫패치는 응급만; 소스 커밋 + CI가 SoT.
