# Skills index

Procedural memory for this lab. Runtime paths `.agents/skills` and `.opencode/skills` symlink here.

| Skill | When |
| --- | --- |
| `gate-worktree-bootstrap` | New project: bare + `main/` then domain worktrees |
| `data-analytics-source-tree` | Where files go |
| `db-duckdb-schema` | DDL / table contracts |
| `db-ingest-h5ad` | h5ad → DuckDB |
| `db-query-patterns` | SQL + Polars, no pandas |
| `data-analytics-eda` | Basic EDA summaries → `/eda` |
| `data-analytics-qc` | MT%/gene filters |
| `data-analytics-dimreduce-cluster` | PCA/UMAP/Leiden |
| `data-analytics-markers` | DEG + panel means |
| `data-analytics-celltype` | Label inference |
| `data-analytics-export` | → `frontend/public/data` |
| `ops-pipeline-orchestration` | Stage order / CLI |
| `ui-echarts` | Chart library SSoT (Apache ECharts only) |
| `ui-methods-explain` | /methods algorithm & architecture explain pages |
| `ui-chrome` | Header nav + footer + SVG icons (`SiteNav`/`SiteFooter`) |
| `ui-astro-app` | Astro shell & routes |
| `ui-design-tokens` | Light CSS tokens |
| `ui-color-system` | Colour roles |
| `ui-typography` | Type scale |
| `ui-layout-grid` | Page grid |
| `ui-viz-eda` | EDA charts (scatter / hist / top genes) |
| `ui-viz-qc` | QC charts (ECharts bar) |
| `ui-viz-umap` | UMAP scatter (ECharts) |
| `ui-viz-dotplot` | Marker dots (ECharts) |
| `ui-viz-violin` | Marker violins (ECharts custom) |

UI skills adapt [Owl-Listener/designer-skills](https://github.com/Owl-Listener/designer-skills) (`color-system`, `design-token`, `typography-scale`, `layout-grid`, `data-visualization`) for this Astro light lab.

## Chatbot pack

Entry: **`blueprint-chatbot`**. Prefixes: `ui-*` · `blueprint-*` · `ai-*`.

| Skill | When |
| --- | --- |
| `blueprint-chatbot` | Chatbot build router (read this first) |
| `ui-chat` | Conversational AI tokens / components |
| `ui-governance` | Design System gate + chat shell (`chat_ui.md`) |
| `blueprint-rag-multiturn` | Multiturn RAG / rag-memory methodology |
| `blueprint-ragas-eval` | RAG quality F/AR/CR eval |
| `blueprint-qa-support-board` | 1:1 support Q&A board + AI draft (adjacent) |
| `ai-prompt-drift-prevention` | Prompt / agent instruction drift guard |
