---
name: gate-worktree-bootstrap
description: Bootstrap every new project as bare git + main/ worktree first, then split domain worktrees (ui, auth, analytics, db, …). Use when starting a new repo, converting a flat checkout into worktrees, or planning ch5-style parallel agents. Pairs with gate-new-project-tree and gate-plan-layout.
---

# Gate: Worktree bootstrap (`main/` first)

**앞으로 프로젝트를 시작할 때** 루트에 바로 코드를 두지 않는다.  
컨테이너에 **bare + `main/`** 을 만들고, 도메인별로 worktree를 나눈다.

## Target layout

```text
<project>/                 # container (not a normal checkout)
├── .bare/                 # bare git repo (SSOT of objects/refs)
├── README.md              # worktree map only — do not edit app code here
├── main/                  # branch main — start here; merge hub
├── ui/                    # branch ui
├── auth/                  # branch auth
├── analytics/             # branch analytics
└── db/                    # branch db
```

도메인 이름은 PLAN에 맞게 바꿀 수 있다. **항상 `main/`은 존재**한다.

| Worktree | Branch | Typical ownership |
| --- | --- | --- |
| `main/` | `main` | Integration, docs, default agent root |
| `ui/` | `ui` | Frontend / chrome / viz |
| `auth/` | `auth` | Login, session, ACL |
| `analytics/` | `analytics` | Analysis / ML / pipeline stages |
| `db/` | `db` | Schema, ingest, warehouse contracts |

## When (triggers)

1. 신규 레포·그린필드 bootstrap 직후
2. flat 체크아웃을 worktree 컨테이너로 바꿀 때
3. 여러 에이전트/사람이 UI·인증·분석·DB를 병렬로 할 때
4. 사용자가 “worktree 나눠”, “main에서 시작해”라고 할 때

## Rules

1. **앱 코드는 worktree 안에서만** 수정. 컨테이너 루트에는 README·맵만.
2. **시작 체크아웃 = `main/`**. 그다음 도메인 브랜치/worktree 추가.
3. **1 worktree ≈ 1 도메인** (상세 소유는 `gate-plan-layout`).
4. 무거운 로컬 산출(`.venv`, `node_modules`, DB 파일)은 기본적으로 **`main/`에만** 두고, 다른 트리는 필요 시 symlink·재설치.
5. 컨테이너 루트에 `gitdir: .bare` 가짜 `.git`을 두지 않는다 (bare에서 `status` 혼선). 명령은 `git --git-dir=.bare …` 또는 worktree 안에서.
6. remote push는 사용자 요청 시에만. 로컬 브랜치/worktree 생성은 OK.

## Greenfield (empty → worktrees)

```bash
PROJECT=/path/to/my-project
mkdir -p "$PROJECT"
cd "$PROJECT"
git init --bare .bare
git --git-dir=.bare symbolic-ref HEAD refs/heads/main

# first commit via temporary non-bare OR orphan worktree
git --git-dir=.bare worktree add -b main main
cd main
# … scaffold files (gate-new-project-tree) …
git add -A && git commit -m "Initial project scaffold."

cd "$PROJECT"
git --git-dir=.bare worktree add -b ui ui main
git --git-dir=.bare worktree add -b auth auth main
git --git-dir=.bare worktree add -b analytics analytics main
git --git-dir=.bare worktree add -b db db main
```

또는 스크립트: [scripts/bootstrap-worktree-main.sh](scripts/bootstrap-worktree-main.sh)

## Convert flat checkout → container

현재 폴더가 일반 `.git` 체크아웃일 때:

```bash
ROOT=/path/to/parent
FLAT=$ROOT/myproj          # current checkout
DEST=$ROOT/myproj          # will become container

mv "$FLAT" "${FLAT}__flat_backup"
mkdir -p "$DEST"
git clone --bare "${FLAT}__flat_backup" "$DEST/.bare"
git --git-dir="$DEST/.bare" remote set-url origin <origin-url>   # if any
git --git-dir="$DEST/.bare" config remote.origin.fetch '+refs/heads/*:refs/remotes/origin/*'
git --git-dir="$DEST/.bare" fetch origin 2>/dev/null || true

git --git-dir="$DEST/.bare" worktree add "$DEST/main" main
git --git-dir="$DEST/.bare" worktree add -b ui "$DEST/ui" main
git --git-dir="$DEST/.bare" worktree add -b auth "$DEST/auth" main
git --git-dir="$DEST/.bare" worktree add -b analytics "$DEST/analytics" main
git --git-dir="$DEST/.bare" worktree add -b db "$DEST/db" main

# move local-only heavies into main/
for p in .venv node_modules frontend/node_modules data/warehouse; do
  [ -e "${FLAT}__flat_backup/$p" ] && mv "${FLAT}__flat_backup/$p" "$DEST/main/$p"
done
rm -rf "${FLAT}__flat_backup"
```

그 후 에이전트 루트를 **`$DEST/main`** 으로 옮긴다 (`move_agent_to_root`).

## Agent checklist

- [ ] 컨테이너 README에 worktree 표 작성
- [ ] `main/WORKTREES.md` (또는 PLAN §3)에 소유 경로 고정
- [ ] 작업 중인 도메인 worktree에서만 커밋
- [ ] `git --git-dir=.bare worktree list`로 브랜치·경로 확인

## Related

- `gate-new-project-tree` — 트리·파일 스캐폴드
- `gate-plan-layout` — PLAN §3 도메인×레이어·worktree 소유
- `gate-grilling` — 도메인 목록이 모호하면 먼저 질문
