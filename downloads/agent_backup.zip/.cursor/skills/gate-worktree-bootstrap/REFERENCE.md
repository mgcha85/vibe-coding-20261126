# Worktree bootstrap — reference

## Why `main/` first

- Single merge hub and default Cursor workspace root.
- Domain agents attach sibling worktrees without fighting one checkout.
- Matches lecture ch5 / harness parallel-dev pattern.

## Naming

| Avoid | Prefer |
| --- | --- |
| Coding in container root | Always `cd main` (or domain wt) |
| `git worktree add ../proj-ui` scattered outside container | All wt under same container |
| One mega `feat/everything` branch | `ui` / `auth` / `analytics` / `db` (or PLAN names) |

## Commands cheat sheet

```bash
GIT_DIR=/path/to/project/.bare

git --git-dir="$GIT_DIR" worktree list
git --git-dir="$GIT_DIR" worktree add -b <name> /path/to/project/<name> main
git --git-dir="$GIT_DIR" worktree remove /path/to/project/<name>
git --git-dir="$GIT_DIR" branch -vv
```

Inside a worktree, normal `git status` / `git commit` work (`.git` file → bare/worktrees/…).

## Example map (PBMC lab)

Container: `/mnt/data/projects/lectures/vibe-coding/src`

| Path | Branch | Owns |
| --- | --- | --- |
| `main/` | `main` | Merge hub |
| `ui/` | `ui` | `frontend/`, `ui-*` |
| `auth/` | `auth` | Login / session |
| `analytics/` | `analytics` | `backend/{qc,cluster,markers,…}` |
| `db/` | `db` | ingest, schema, DuckDB |

## Pitfalls

- Do not leave a second full `.git` directory from the old flat checkout.
- Do not point container `.git` at `.bare` if `core.bare=true` — use `--git-dir=.bare`.
- After convert, move agent root to `…/main`.
