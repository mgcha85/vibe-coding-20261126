#!/usr/bin/env bash
# Bootstrap <project>/ as bare + main + domain worktrees.
# Usage: bootstrap-worktree-main.sh /path/to/project [ui,auth,analytics,db]
set -euo pipefail

PROJECT="${1:?project directory}"
DOMAINS_CSV="${2:-ui,auth,analytics,db}"

mkdir -p "$PROJECT"
cd "$PROJECT"

if [[ -e .bare || -e main ]]; then
  echo "Refusing: .bare or main already exists in $PROJECT" >&2
  exit 1
fi

git init --bare .bare
git --git-dir=.bare symbolic-ref HEAD refs/heads/main

git --git-dir=.bare worktree add -b main main

# Seed README in main if empty
if [[ ! -f main/README.md ]]; then
  cat > main/README.md <<'EOF'
# Project

Default worktree: `main/`. See `WORKTREES.md` and container `../README.md`.
EOF
  cat > main/WORKTREES.md <<EOF
# Worktrees

| Path | Branch |
| --- | --- |
| main/ | main |
EOF
  (
    cd main
    git add README.md WORKTREES.md
    git -c user.email="${GIT_AUTHOR_EMAIL:-devnull@example.com}" \
        -c user.name="${GIT_AUTHOR_NAME:-bootstrap}" \
        commit -m "Initial main worktree scaffold." || true
  )
fi

IFS=',' read -ra DOMAINS <<< "$DOMAINS_CSV"
MAP_ROWS="| main/ | main |"
for d in "${DOMAINS[@]}"; do
  d="${d// /}"
  [[ -z "$d" || "$d" == "main" ]] && continue
  if [[ -e "$d" ]]; then
    echo "Skip existing $d" >&2
    continue
  fi
  git --git-dir=.bare worktree add -b "$d" "$d" main
  MAP_ROWS+=$'\n'"| ${d}/ | ${d} |"
done

cat > README.md <<EOF
# Worktree container

Do not edit app code here. Use a worktree.

| Path | Branch |
| --- | --- |
${MAP_ROWS}

\`\`\`bash
git --git-dir=.bare worktree list
\`\`\`
EOF

# Refresh WORKTREES.md on main
{
  echo "# Worktrees"
  echo
  echo "| Path | Branch |"
  echo "| --- | --- |"
  echo "$MAP_ROWS"
} > main/WORKTREES.md

git --git-dir=.bare worktree list
echo "Done. Start in: $PROJECT/main"
