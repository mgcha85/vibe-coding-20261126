---
name: data-analytics-export
description: Exports DuckDB analytical tables into frontend/public/data for Astro. Use after any backend stage that changes warehouse tables or when refreshing the dashboard. For query syntax use db-query-patterns; for page wiring use ui-astro-app.
---

# Data Analytics Export

FE는 DuckDB를 열지 않는다. 이 단계만 `frontend/public/data/`에 쓴다.

## Artifact map

| File | Source |
| --- | --- |
| `overview.json` | pipeline_runs + cell counts |
| `eda_summary.json` / `eda_cells.json` | shape, top genes, per-cell EDA (`data-analytics-eda`) |
| `qc_summary.json` | QC filter stats |
| `qc_cells.json` | cells_qc sample/all for violin/scatter |
| `umap_points.json` | embeddings_umap ⋈ clusters ⋈ celltypes? |
| `markers_top.json` | markers where rank ≤ 10 |
| `marker_means.json` | marker_means |
| `celltypes.json` | celltypes |
| `methods_pipeline.json` | methods_meta + live metrics (schematic/funnel; visitor-facing copy) |

Prefer JSON for ≤50k rows; Parquet optional for larger.

## Rules

- Atomic write: temp file → rename
- Schema version field `schema_version: 1` in JSON wrappers
- Never commit giant binary dumps beyond public/data snapshots needed for static build
- Run after stages 1–5 or as `python -m backend.export`
