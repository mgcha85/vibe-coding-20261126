---
name: ai-prompt-drift-prevention
description: "Framework to prevent AI coding agent context drift, scope creep, and unintended code modifications using INTENT.md, 3-tier defense, and structured validation."
---

# Prompt Drift Prevention & INTENT.md Framework (에이전트 탈선 방지 프레임워크)

AI 코딩 에이전트(Cursor, Windsurf, Claude Code, Antigravity 등)가 여러 턴을 수행하면서 사용자의 원래 의도와 다른 엉뚱한 방향으로 코드를 수정하거나 오버엔지니어링하는 '컨텍스트 드리프트(Context Drift)'를 방지하는 실전 프레임워크입니다.

---

## 1. 문제 정의: 에이전트 드리프트의 3대 원인
1. **암묵적 가정 (Implicit Assumptions)**: 프롬프트에 명시되지 않은 요구사항을 에이전트가 자의적으로 상상하여 코딩.
2. **범위 확장 (Scope Creep)**: 지시하지 않은 리팩토링이나 패키지 추가를 단행하여 기존 코드 파괴.
3. **히스토리 압축 손실**: 턴이 길어지면서 첫 번째 턴에서 말했던 핵심 제약조건이 컨텍스트 윈도우 밖으로 밀려남.

---

## 2. 해결책: 3계층 방어막 (3-Tier Defense)

```mermaid
graph TD
    User["사용자 프롬프트"] --> G1{"Grill-me 검증<br>(INTENT.md 100% 명확한가?)"}
    G1 -->|"모호함 존재"| Ask["사용자에게 질문 (Grill-me)"]
    Ask --> User
    G1 -->|"완전 명확"| Plan["PLAN.md 작성 (스택, 아키텍처, 로드맵)"]
    Plan --> G2{"사용자 PLAN 승인"}
    G2 -->|"수정 요청"| Plan
    G2 -->|"승인 완료"| Exec["코드 구현 시작 (INTENT.md 고정)"]
```

### Layer 1: Grill-me 프로토콜 (착수 전 모호성 소탕)
- 에이전트는 프롬프트 접수 시 구현을 시작하지 않고 "무엇이 모호한가?"를 먼저 점검.
- 데이터 타입, UI 상태, 에러 처리, 권한 등에 대해 질문하여 `INTENT.md`에 결정을 못 박음.

### Layer 2: Out of Scope 강제 (하지 말아야 할 것 명시)
- `INTENT.md`의 `## 3. Out of Scope (Do NOT)` 섹션에 손대지 말아야 할 파일, 건드리지 말아야 할 모듈을 명시.
- 에이전트는 코드 작성 시 이 목록을 체크리스트로 확인.

### Layer 3: PLAN.md 사전 승인 (Pre-execution Gate)
- 전체 코딩 계획을 마크다운 문서로 작성하여 사용자에게 보여주고 승인을 득함.
- 잘못된 설계로 인한 대규모 롤백을 원천 차단.
