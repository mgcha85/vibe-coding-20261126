---
name: ui-astro-app
description: Scaffolds and maintains the Astro frontend for PBMC3k lab pages. Use when creating frontend/, routes, layouts, or wiring public/data JSON into pages. For tokens use ui-design-tokens; for charts use ui-viz-* skills.
---

# UI Astro App

모든 사용자 시각화의 호스트는 Astro다. Jupyter/HTML 단발 리포트로 대체하지 않는다.

## App skeleton

```
frontend/
├── package.json
├── astro.config.mjs
├── src/
│   ├── layouts/BaseLayout.astro
│   ├── pages/index.astro
│   ├── pages/raw.astro
│   ├── pages/eda.astro
│   ├── pages/qc.astro
│   ├── pages/umap.astro
│   ├── pages/markers.astro
│   ├── pages/celltypes.astro
│   ├── pages/methods/index.astro
│   ├── pages/methods/[stage].astro
│   ├── components/viz/
│   └── styles/tokens.css
└── public/data/          # from data-analytics-export
```

## Rules

1. `BaseLayout`에 light tokens 로드. `html` 기본 테마 light.
2. 한국어 UI 카피 기본 (`PROJECT`/`INTENT` 페르소나).
3. 페이지는 `public/data/*.json`만 fetch/import. DuckDB 금지.
4. 결과 차트는 `src/components/viz/*` + **Apache ECharts** (`ui-echarts`). Methods 설명은 HTML 보드·스키매틱·퍼널·타임라인 (`ui-methods-explain`). 웹 카피에 스택명·C4 레벨명 금지. `/raw`는 `RawDataTable`로 세포 표 + 페이지네이션(20/50/100, 기본 50, 상한 200).
5. 로딩 시 스켈레톤; “데이터 없음” 플리커 금지.
6. Thin header (브랜드 + 단계 내비). 대시보드 카드 난립 금지 — 페이지당 한 목적.
7. `BaseLayout`에 헤더+푸터 (`SiteNav` / `SiteFooter`, `ui-chrome`).

## Nav order

개요 → 원본 데이터 → 분석 방법 → 탐색(EDA) → 품질 관리 → UMAP 군집 → 마커·차별 발현 → 세포 유형.

사이트 크롬(아이콘 내비·푸터·에셋): `ui-chrome`.

## GitHub Pages

- `.github/workflows/pages.yml` — `frontend` build → `actions/deploy-pages`
- `astro.config.mjs`: CI에서 `SITE` + `BASE_PATH=/<repo>/`
- 모든 내부 링크·JSON `fetch`는 `withBase()` (`src/lib/paths.ts`)
- Pages Source는 **GitHub Actions** (legacy `/docs` branch 아님)
