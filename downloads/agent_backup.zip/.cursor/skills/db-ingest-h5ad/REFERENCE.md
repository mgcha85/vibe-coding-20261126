# Ingest Reference

```python
import duckdb
import polars as pl
import scanpy as sc
from scipy import sparse

from backend.common.paths import H5AD, DUCKDB

adata = sc.read_h5ad(H5AD)
adata.var_names_make_unique()

genes = pl.DataFrame({
    "gene_symbol": adata.var_names.to_list(),
    "gene_id": adata.var["gene_ids"].astype(str).to_list(),
    "is_mt": [g.startswith("MT-") for g in adata.var_names],
})

cells = pl.DataFrame({"barcode": adata.obs_names.to_list()})

X = adata.X.tocoo() if sparse.issparse(adata.X) else sparse.coo_matrix(adata.X)
barcodes = adata.obs_names.to_numpy()
genes_arr = adata.var_names.to_numpy()
counts = pl.DataFrame({
    "barcode": barcodes[X.row],
    "gene_symbol": genes_arr[X.col],
    "count": X.data.astype("float64"),
})

con = duckdb.connect(str(DUCKDB))
# apply DDL from db-duckdb-schema, then:
con.execute("DELETE FROM counts; DELETE FROM cells_raw; DELETE FROM genes;")
con.register("genes_pl", genes)
con.execute("INSERT INTO genes SELECT * FROM genes_pl")
# … cells_raw, counts similarly
```

QC 컬럼(`n_genes_by_counts` 등)은 ingest에서 비워 두거나 0으로 두고, **계산은 `data-analytics-qc`**에서 `cells_qc`에 쓴다.
