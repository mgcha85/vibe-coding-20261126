---
name: db-ingest-h5ad
description: Loads PBMC3k AnnData/h5ad into DuckDB warehouse tables. Use when ingesting raw counts, rebuilding warehouse from data/raw, or implementing backend/ingest. For schema DDL use db-duckdb-schema; for QC filtering use data-analytics-qc.
---

# DB Ingest H5AD

원본 `data/raw/pbmc3k_raw.h5ad`를 DuckDB로 적재하는 1단계다. 다운로드하지 않는다.

## Procedure

1. Read-only open h5ad via anndata/scanpy.
2. `var_names_make_unique()`.
3. Build Polars frames for genes / cells skeleton (no pandas).
4. Extract sparse `.X` → COO long `(barcode, gene_symbol, count)` with Polars or numpy→list batches.
5. DuckDB: `CREATE SCHEMA` tables per `db-duckdb-schema`, then `INSERT`/`REGISTER` Polars.
6. Mark `genes.is_mt = gene_symbol LIKE 'MT-%'`.
7. Log `pipeline_runs` stage=`ingest`.

## Performance

- Batch COO inserts (예: 100k~500k rows). 전체 dense densify 금지.
- 기존 warehouse가 있으면 ingest는 **재생성**이 기본(실습 재현성). `pipeline_runs`에 기록.

## Done when

- `SELECT COUNT(*) FROM cells_raw` = 2700
- `SELECT COUNT(*) FROM genes` = 32738
- `counts` row count > 0 and no null keys

연결 헬퍼·의사코드는 [REFERENCE.md](REFERENCE.md).
