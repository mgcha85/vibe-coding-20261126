---
name: ui-viz-dotplot
description: Astro marker dot plot (cluster × gene) using Apache ECharts scatter + visualMap. Use when building marker overview on /markers. For means data use data-analytics-markers; for ECharts rules use ui-echarts.
---

# UI Viz Dot Plot

**Chart library: Apache ECharts only** (`ui-echarts`).

## Encoding

- ECharts `scatter` on category×category axes (gene × Leiden)
- `symbolSize` ← frac expressing
- `visualMap` (continuous, single-hue sky ramp) ← per-gene scaled mean expression

## Data

`marker_means.json` (`mean_expr`, `frac_expressing`)

## Anti-patterns

Manual SVG `<circle>` matrices; rainbow categorical colour for expression magnitude.
