---
name: db-query-patterns
description: DuckDB-first query patterns with Polars as secondary. Use when writing SELECT/aggregations, bridging AnnData obs to SQL, or exporting tables. Forbids pandas. For schema use db-duckdb-schema; for Astro files use data-analytics-export.
---

# DB Query Patterns

## Engine priority

1. **DuckDB SQL** — 필터, 조인, 그룹 집계, 파일 export
2. **Polars** — 파이썬 쪽 가벼운 reshape, 차트용 소형 frame
3. **Never pandas**

## Connection

```python
import duckdb
from backend.common.paths import DUCKDB

def connect(read_only: bool = False):
    return duckdb.connect(str(DUCKDB), read_only=read_only)
```

## Patterns

- Register Polars: `con.register("t", df)` → `SELECT * FROM t`
- Back to Polars: `con.execute("SELECT …").pl()`
- Export: `COPY (SELECT …) TO 'frontend/public/data/x.parquet' (FORMAT PARQUET)`
- Marker panel means: SQL `AVG` over joined counts + clusters (log-normalized values이 stage에서 별도 테이블이면 그쪽 사용)

## AnnData bridge

AnnData `.obs`/`.var`가 pandas여도 **import pandas 하지 않는다**.  
`dict`/`list`/`to_numpy()`로 뽑아 즉시 Polars `DataFrame`을 만든다.

## Anti-patterns

- FE에서 DuckDB 파일 직접 open
- 매 요청마다 full counts 스캔 (export 스냅샷 사용)
- `FETCH ALL`로 수백만 COO를 파이썬 리스트에 적재 후 집계
