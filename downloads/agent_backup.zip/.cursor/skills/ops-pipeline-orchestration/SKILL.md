---
name: ops-pipeline-orchestration
description: Orders PBMC3k pipeline stages and CLI entrypoints. Use when running the full lab pipeline, deciding next incomplete PLAN.md phase, or wiring make/just targets. For individual stages use the matching data-analytics-* or db-* skill.
---

# Ops Pipeline Orchestration

## Stage graph

```
ingest → qc → cluster → markers → annotate → export
           ↘ eda (JSON)                          ↓
             ui-viz-eda / ui-viz-qc / umap / markers  Astro pages
```

## CLI (target)

```bash
.venv/bin/python -m backend.ingest
.venv/bin/python -m backend.qc
.venv/bin/python -m backend.cluster
.venv/bin/python -m backend.markers
.venv/bin/python -m backend.annotate
.venv/bin/python -m backend.export
cd frontend && npm run dev
```

## Rules

1. Skip ahead 금지. warehouse 테이블 존재 여부를 stage 시작 시 assert.
2. 실패 시 `pipeline_runs.status='failed'` 기록 후 중단.
3. 부분 재실행: 해당 stage부터 export까지.
4. 사용자 프롬프트가 모호하면 grill-me: 어느 stage인지 확인.

## Definition of done (full run)

- DuckDB populated through `celltypes`
- Astro `npm run build` succeeds reading `public/data`
- No `import pandas` in `backend/` or `scripts/`
