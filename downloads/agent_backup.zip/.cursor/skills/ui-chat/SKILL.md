---
name: ui-chat
description: >-
  Conversational AI chat UI tokens, layout, and component specs (sidebar, bubbles,
  input bar, sources, suggested questions, quick actions). Use when styling or
  restructuring agent chat pages, message threads, session rails, or chat chrome.
  Colors/type defer to ui-design-tokens and ui-typography when present.
---

# Conversational Chat UI

제품 중립 대화형 AI 챗 UI 스펙. 토큰·타이포는 가능하면 `ui-design-tokens` / `ui-typography`를 따른다.  
가이드에 없는 색을 새로 만들지 말고, Status/Support 팔레트 또는 디자인 토큰에서 고른다.

적용 대상 예:

| 대상 | 경로 예 |
|------|------|
| 챗 페이지 | `frontend/src/pages/*Chat*.tsx` / `*.astro` |
| 스타일 | chat CSS (`chat-*` / `ac-*` prefix) |
| 응답 블록 | `components/**/chat/*` |

---

## 0. 디자인 원칙 (4)

| 원칙 | EN | 내용 |
|------|----|------|
| 명확성 | Clarity | 질문·답변·출처를 시각적으로 구분. 지금 무엇을 보고 무엇을 할 수 있는지 한눈에. |
| 일관성 | Consistency | 동일 디자인 토큰·타이포·아이콘을 앱 전역과 맞춘다. |
| 효율성 | Efficiency | 추천 질문·퀵스타트로 입력 비용 절감. 자주 쓰는 대화는 즐겨찾기 고정. |
| 신뢰성 | Trust | 답변에 출처를 제시. 좋아요·재생성으로 품질 피드백. |

---

## 1. 기본 환경

| 항목 | 값 |
|------|-----|
| 기준 해상도 | 1920 × 1080 (최소 가용 1920 × 963) |
| 레이아웃 | **Left Area + Main** (Main은 Flexible) |
| 서체 | **Pretendard** / IBM Plex Sans KR (`ui-typography`) |

### 화면 규격

| 항목 | 값 |
|------|-----|
| Left Area 전체 (레일 + 패널) | 324 px |
| Favorites / Icon Rail | 64 px |
| Left Menu Panel | 260 px |
| 최소화(Collapse) 시 | 64 px (아이콘 레일만) |
| Main 폭 | Flexible (잔여) |
| 대화 / 콘텐츠 / 입력창 최대 폭 | **720 px** |
| 컨트롤 모서리 반경 | 2 / 8 px |
| 입력창 모서리 반경 | 14 / 20 px |
| 전송 버튼 | 34–36 px · 원형 |
| 사용자 말풍선 반경 | 16 / 0 / 16 / 16 |
| 본문 텍스트 | 14 px / line-height 1.65 |
| 항목 모서리 반경 | 8 px |
| 프로필 아바타 | 26 px · 원형 |

---

## 1.1 메시지 본문 렌더링 (하드룰)

챗봇 말풍선은 **역할과 무관하게** 마크다운 + allowlist HTML로 렌더한다.

| 적용 | 규칙 |
|------|------|
| 사용자 질문 | MD/HTML 렌더 **필수** (`textContent` only 금지) |
| AI 답변 | MD/HTML 렌더 **필수** (동일 파이프라인) |
| MD | 제목 `#`–`####`, 굵게/기울임, 코드, 목록, 표, 인용, 링크 |
| HTML | `ui-governance/chat_ui.md` allowlist만. 나머지 strip |
| 실패 신호 | 화면에 원시 `**bold**`, `# 제목`, 이스케이프된 `&lt;strong&gt;`이 보이면 버그 |

정본 동작·allowlist → **`ui-governance/chat_ui.md` «본문 렌더링»**.  
이 레포 구현 SSOT → `frontend/src/lib/chat-markdown.ts`.

---

## 12. 챗 파일 카드 · 형식 아이콘

첨부·생성 파일 카드의 PDF / DOC / XLS / PPT / MD / MP4 칩은 **`ui-governance/file_type_icons.md`** + `assets/file-types/*.svg` 를 적용한다. 색·약어 임의 변경 금지.

---

상세 → **[REFERENCE.md](REFERENCE.md)**.
