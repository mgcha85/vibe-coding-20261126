# ui-chat tokens & components



## 2. Color Token

### Primary (Teal · Key `#2D9BB2`)

| step | hex | | step | hex |
|------|-----|-|------|-----|
| 50 | `#EBFDFA` | | 500 | `#3EC2CF` |
| 100 | `#D9FCF4` | | **600 (Key)** | **`#2D9BB2`** |
| 200 | `#B4FAEF` | | 700 | `#1F7C95` |
| 300 | `#8BF0E9` | | 800 | `#135678` |
| 400 | `#6BE1E2` | | 900 | `#0B3E63` |

### Secondary (Violet · Key `#554596`)

| step | hex | | step | hex |
|------|-----|-|------|-----|
| 50 | `#F3EEFC` | | 500 (Key) | `#554596` |
| 100 | `#E6DEF9` | | 600 | `#433A7E` |
| 200 | `#CDBFF4` | | 700 | `#2E226C` |
| 300 | `#A897DF` | | 800 | `#1E1657` |
| 400 | `#8372C0` | | 900 | `#140D48` |

### Grey Scale

| step | hex | | step | hex |
|------|-----|-|------|-----|
| 50 | `#f1f1f1` | | 600 | `#6E706F` |
| 100 | `#F1F4F3` | | 700 | `#5B5C5B` |
| 200 | `#EBEEED` | | 750 | `#464747` |
| 300 | `#DDE0DF` | | 800 | `#3C3E3D` |
| 350 | `#CACCCB` | | 850 | `#282929` |
| 400 | `#B9BCBB` | | 900 | `#1F1F1F` |
| 500 | `#979998` | | Black | `#000000` |

주의: 입력창 첨부 썸네일 배경만 `Grey100 · #F1F1F1` 로 표기됨(가이드 내 표기 불일치). 그 외 Grey100 은 `#F1F4F3`.

### Status (Key 500, 6단계: 50/100/300/500/700/900)

| 이름 | 용도 | 50 | 100 | 300 | **500 Key** | 700 | 900 |
|------|------|----|-----|-----|-------------|-----|-----|
| Confirmed | 확인 / 정상 | `#F1FDF7` | `#DCFBEA` | `#56D8AA` | **`#00806A`** | `#01463A` | `#052923` |
| Warning-Minor | 경고 (낮음) | `#FFFCE9` | `#FFF8CD` | `#FFE56A` | **`#FFC907`** | `#B78803` | `#7A5501` |
| Warning-Major | 경고 (높음) | `#FFF7EB` | `#FEEFD6` | `#FFCB7A` | **`#FF9322`** | `#B75511` | `#7A2B06` |
| Error | 오류 | `#FEF1EB` | `#FEE6DB` | `#FDA293` | **`#F94B50`** | `#B32542` | `#770E36` |
| Done/Offline | 종료·비활성·Idle | `#F7F9F8` | `#F1F4F3` | `#DDE0DF` | **`#979998`** | — | — |

단계 라벨: Extra Bright / Bright / Light / Normal / Strong / Extreme.
Grey(Done/Offline)는 Offline·Unavailable·Disconnect·종료·비활성화·Idle 상태에 쓴다.

### Support Palette (차트·그래픽만)

Deepblue (Key 400 `#5E5FB7`), Lime (Key 600 `#89B129`), Pink (Key 500 `#E12991`), Lightblue (Key 500 `#77A5FF`).

### 주요 사용 컬러 매핑 (이게 실무 기준)

| 역할 | hex | 용도 |
|------|-----|------|
| Primary-600 | `#2D9BB2` | 전송 버튼, 링크, 선택/활성 표시, 로고 |
| Primary-500 | `#3EC2CF` | 사이드바 선택 항목 강조 (Mint) |
| Primary-100 | `#D9FCF4` | 퀵스타트 강조 카드 배경 (Mint) |
| Grey-200 | `#EBEEED` | 사용자 말풍선 배경, 아이콘 레일 배경 |
| Grey-300 | `#DDE0DF` | 입력창·카드 보더 |
| Grey-50 | `#f1f1f1` | 사이드바 패널·페이지 배경 |
| Grey-900 | `#1F1F1F` | 제목·본문 기본 텍스트 |
| Secondary-500 | `#554596` | 사용자 아바타 등 보조 강조 |

---

## 3. 타이포그래피

기본 서체 **Pretendard** / IBM Plex Sans KR, 13 px 본문 기준 스케일.

| Role | Size | Weight | 용도 |
|------|------|--------|------|
| Display | 32px | Bold 700 | 대표 타이틀 |
| Title | 24px | Bold 700 | 페이지 제목 |
| Heading | 18px | Bold 700 | 섹션 헤더 |
| Subtitle | 16px | Medium 500 | 보조 제목 |
| Body | 14px | Regular 400 | 본문 기본 |
| Body sub | 13px | Regular 400 | 본문 보조 |
| Label | 12px | Medium 500 | 라벨 · 캡션 |
| Caption | 11px | Regular 400 | 보조 정보 |

폰트 컬러는 챗 팔레트(또는 `ui-design-tokens`) 내에서만. 주요 텍스트는 Grey Scale 500~900 범위 권장.

### Radius / Spacing 토큰

| 토큰 | 값 | 용도 |
|------|----|------|
| radius-xs | 2px | 버튼 · 입력창 등 컨트롤 |
| radius-sm | 6px | 태그 · 작은 카드 |
| radius-md | 8px | 카드 · 팝업 · 이미지 |

space-1..8 = 4 / 8 / 12 / 16 / 20 / 24 / 32 px.

---

## 4. Left Area

### 구성

- `Left Area = Favorites(64px) + Left Menu(260px)` — Favorites 사용 시
- `Left Area = Left Menu(260px)` — Favorites 미사용 시
- 접으면 64px 아이콘 레일만 남기고 Main 확장

### 3가지 상태

| 상태 | 내용 |
|------|------|
| 기본 | 프로젝트 미사용. 새 대화·검색 + 즐겨찾기/이력 목록. 탭 없음 |
| 프로젝트 사용 | 상단에 **대화 / 프로젝트** 탭. 프로젝트 폴더 목록 + 항목별 대화 수 |
| 최소화 | 패널 접고 64px 레일만. 대화 집중·좁은 화면용. 레일 토글로 복귀 |

### 기본 메뉴 항목

| 항목 | 설명 |
|------|------|
| 새로운 대화 시작 | 항상 최상단 고정. **Grey-300 보더**의 강조 항목 |
| 지난 대화 검색 | 이력 전체 키워드 탐색 |
| 프로젝트 | 대화를 폴더 단위로 묶어 관리 |

### 아이콘 레일 구성

토글 버튼(접기/펴기) / `+` 버튼(다른 AI 서비스 추가) / 설정 버튼(기본 환경 설정 필요 시 추가).
레일 아이콘 예: 패널 열기, 새 대화, 검색, 프로젝트, 최근 대화.

### Favorites 메뉴 상태 컬러 (2종 중 택1)

| 타입 | 상태 | 배경 | 아이콘 | 텍스트 |
|------|------|------|--------|--------|
| Grey | Default | `#EBEEED` | `#6E706F` | `#1F1F1F` |
| Grey | Selected | `#FFFFFF` | `#6E706F` | `#1F1F1F` |
| Primary | Default | `#2D9BB2` | `#FFFFFF` | `#FFFFFF` |
| Primary | Selected | `#2D9BB2` | `#FFFFFF` | `#FFFFFF` |

선택 상태는 해당 AI 서비스 사용 중 계속 유지.

### 대화 목록 기능

- **고정(Pin)**: 제목 hover → `⋮` 더보기 → 핀. 고정 항목은 날짜 구분 없이 최상단. `⋮` → 고정 해제로 복귀.
- **이름 변경**: `⋮` → 이름 변경 → 팝업 입력 → 확인.
- **삭제**: `⋮` → 삭제 → 팝업에서 재확인 → 취소/삭제.
- **날짜별 색인**(옵션): `오늘`, `26/06/05`, `26/06/01` 라벨로 자동 그룹화. 최신순 하향.
- **하단 버튼 영역**: 용도별 아이콘 버튼. hover 시 상세 팝업. 버튼 많으면 화살표 아이콘 추가 → hover 시 영역 확장(접기도 화살표로 표현).

---

## 5. Main — 기본 상태 (대화 시작 전)

구성: **A 환영 메시지 · B 입력창** (+ 옵션 **C 추천 질문 · D 빠른 실행**).

- 추천 질문 예: `회의실 예약은 어떻게 하나요?`, `연차 정산은 언제부터 가능한가요?`, `사내망 인증 절차를 알려주세요`
- 빠른 실행 예: 공식문서검색 / 글작성하기 / 코드 작성하기 / 데이터조회 / 답변하기
- 퀵스타트 카테고리 예: 정의(용어·개념 설명) / 절차(단계별 진행) / 프로세스(업무 흐름 시각화) / 비교(항목 간 차이)

---

## 6. Main — 질문·답변 상태

질문 입력 시 화면 전환: 대화 이름 자동 생성 → 사용자 말풍선 + AI 답변 시간순 누적 → **입력창 하단 고정**.

### 대화 이름

| 항목 | 값 |
|------|-----|
| 폰트 | Pretendard |
| 크기 | 16 px |
| 두께 | Bold 700 |
| 컬러 | Grey900 `#1F1F1F` |

### 사용자 말풍선 (Grey / Mint 2종 택1)

| 타입 | 배경 | 텍스트 | Radius | Padding |
|------|------|--------|--------|---------|
| Grey (기본) | Grey200 `#EBEEED` | Grey900 `#1F1F1F` | 16 / 0 / 16 / 16 | 12 × 16 px |
| Mint (Primary) | Primary100 `#D9FCF4` | Grey900 `#1F1F1F` | 16 / 0 / 16 / 16 | 12 × 16 px |

사용자 말풍선은 **우측 정렬**, 13 px. AI 답변은 **좌측 · 배경 없음 · 본문 14 px**.

답변 블록은 세로로만 쌓는다. 순서: 본문 → 출처 카드 → 액션 아이콘. 이 셋을 한 flex 행에 넣지 않는다. 폭이 쪼개져 글자가 한 자씩 내려가면 실패다. 액션 아이콘만 가로다.

다국어 값 `{en,ko,pl,zh}`는 출처 카드에 한국어만 보인다. 언어 set 원문을 카드에 그대로 두지 않는다. `* `, `- `, `1.` 목록과 `**굵게**`는 마크다운으로 그린다.

---

## 7. AI 답변

### 기본 답변 3영역 — 본문 · 참고문서 · 추가 질문 제안

| 영역 | 항목 | 값 |
|------|------|-----|
| 본문 | 폰트 크기 | 제목 16 px / 본문 14 px |
| 본문 | 컬러 | Grey900 `#1F1F1F` |
| 본문 | 링크 | 14px / underline / Primary600 `#2D9BB2` |
| 참고문서 | 제목 | 16px / Grey900 `#1F1F1F` |
| 참고문서 | 문서명 | 14px / underline / Primary600 `#2D9BB2` |
| 참고문서 | 보조 텍스트 | Grey600 `#6E706F` |
| 참고문서 | 구분선 | Grey100 `#F1F4F3` |
| 추가 질문 제안 | 폰트 크기 | 제목 16 px / 본문 14 px |
| 추가 질문 제안 | 컬러 | Grey900 `#1F1F1F` |

답변 상단 AI Agent 아이콘은 필요 시 추가 가능(옵션).

### 생각하는 과정 (Reasoning)

진행 단계를 순차 노출: **질문 분석 · 웹 검색 · 결과 수집 · 완료**. 필요 시 `<중단하기>` 버튼 추가.

| 항목 | 값 |
|------|-----|
| 진행 텍스트 | Grey600 `#6E706F` |
| 조사 내용 배경 | Grey100 `#F1F4F3` |
| 제목 텍스트 | Grey900 `#1F1F1F` |
| 보조 텍스트 | Grey500 `#979998` |
| Radius | 12 px |

### 출처 표시

하단 `<출처 확인하기>` 클릭 → 상세 출처 영역 오픈, `<닫기>` 로 복귀.

| 항목 | 값 |
|------|-----|
| 출처 영역 배경 | Grey50 `#F7F9F8` |
| 출처 문서명 | 16px / Bold / Grey850 `#282929` |
| 보조 텍스트 | Grey750 `#464747` |
| URL | Grey600 `#6E706F` |

### 리액션 (복사 · 좋아요 · 싫어요 [· 재생성])

클릭 시 하단에 안내 말풍선 노출.

| 항목 | 값 |
|------|-----|
| 아이콘 | 20 px · Lined |
| 기본 컬러 | Grey600 `#6E706F` |
| 활성 컬러 1 | Primary600 `#2D9BB2` (복사·좋아요) |
| 활성 컬러 2 | Error500 `#F94B50` (싫어요) |
| 안내 말풍선 배경 | White `#FFFFFF` (텍스트 Grey800 `#3C3E3D`) |
| 안내 말풍선 라인 | 1px solid Border/Basic `#DDE0DF` |

---

## 8. 프로젝트

Left Menu **프로젝트 탭** 전환 → 프로젝트 목록 확인 + 새 프로젝트 생성. 키워드 검색 + 생성일 정렬 제공.

### 프로젝트 대화 카드

| 항목 | 값 |
|------|-----|
| 카드 배경 | Grey50 `#F7F9F8` |
| Hover | Grey200 `#EBEEED` |
| 프로젝트명 | 16px / Medium / Grey900 `#1F1F1F` |
| 주제 | 13px / Regular / Grey600 `#6E706F` |
| 날짜 | 12px / Regular / Grey400 `#B9BCBB` |
| Radius | 8 px |

`새 프로젝트 생성` → 이름 + 주제/목표/설명 입력 → `프로젝트 생성` 버튼.

---

## 9. 컴포넌트 스펙

### 9.1 버튼

`Contained` / `Outlined` 중 목적에 맞게. 세로 사이즈 3종:

| Size | Height |
|------|--------|
| Large | 36 px |
| Medium | 32 px |
| Small | 28 px |

특수 버튼:

| 버튼 | 사이즈 | 형태 | 컬러 | Hover | 아이콘 |
|------|--------|------|------|-------|--------|
| 첨부 | 36 × 36 px | 원형 · Outlined | Grey300 `#DDE0DF` | Grey100 `#F1F4F3` | 20 px · Grey600 `#6E706F` |
| 전송 | 36 × 36 px | 원형 · Contained | Primary600 `#2D9BB2` | Primary700 `#218399` | 20 px · White `#FFFFFF` |

### 9.2 입력창 (Input Bar)

Placeholder 예: `찾고싶은 문장을 입력하세요`. 모델 선택 · 첨부 · 전송을 함께 배치.

| 상태 | 항목 | 값 |
|------|------|-----|
| 기본 | Border | 1px solid Grey300 `#DDE0DF` |
| 기본 | Text | Pretendard · Medium · 14px · Grey500 `#979998` |
| 기본 | Border Radius | 20px |
| 입력 중 | Text | Pretendard · Medium · 14px · Grey900 `#1F1F1F` (전송 버튼 활성화) |
| 첨부 썸네일 | 배경 | Grey100 `#F1F1F1` |
| 첨부 썸네일 | 파일명 · 확장자 | Medium · 14px · Grey600 `#6E706F` · 가운데 정렬 |
| 첨부 썸네일 | Border Radius | 12px |
| 첨부 썸네일 | 삭제 | `<닫기>` 아이콘 버튼 우측 상단 |

상태 세트: 기본 / 포커스 / 입력 중 / 비활성.

**모델 선택**: 입력창 우측 화살표 → 전체 모델 리스트. 기본값(빠른 모델)을 별도 지정.
예시 라벨: `빠른 답변 · AI Pro · 심화 모드`, 리스트 예 `AA Pro / BB Flash / CC Lite`.

**파일 첨부**: 첨부 아이콘 → 팝업으로 `파일 업로드` / `내 파일함` 선택. 내 파일함은 개인폴더·공용폴더 트리 + 파일 목록.

### 9.3 카드형 질문 (추천 질문)

| 타입 | 배경 | Hover | 제목 | 설명 | Radius | Padding |
|------|------|-------|------|------|--------|---------|
| Grey | White `#FFFFFF` | Grey200 `#EBEEED` | Grey900 `#1F1F1F` | Grey600 `#6E706F` | 8 px | 14 × 16 px |
| Mint | Primary50 `#ECFCF9` | Primary100 `#D9FCF4` | Grey900 `#1F1F1F` | Grey600 `#6E706F` | 8 px | 14 × 16 px |

카드 아이콘은 서비스 특성 반영 전용 스타일 사용.

### 9.4 빠른 실행

| 상태 | 항목 | 값 |
|------|------|-----|
| 기본 | 배경 | White `#FFFFFF` |
| 기본 | Hover | Grey300 `#DDE0DF` |
| 기본 | 텍스트 | Grey900 `#1F1F1F` |
| 기본 | 보더 | Grey300 `#DDE0DF` |
| 기본 | Radius | 8 px |
| 탭 선택(hover) | 목록 배경 | White `#FFFFFF` |
| 탭 선택(hover) | 텍스트 | Grey600 `#6E706F` |
| 하위 항목 hover | 배경 | Grey100 `#F1F4F3` |
| 하위 항목 hover | 텍스트 | Grey600 `#6E706F` |
| 하위 항목 hover | Radius | 10 px |

카테고리 탭 hover → 예시 작업 목록. 항목 클릭 시 해당 텍스트가 사용자 메시지로 전송.

### 9.5 팝업

페이지 전환 없이 짧은 입력·확인 작업(이름 변경, 삭제 확인 등)에 사용.

| 항목 | 값 |
|------|-----|
| 배경 | White `#FFFFFF` |
| 딤드 오버레이 | Grey900 40% · `rgba(31,31,31,0.4)` |
| Border Radius | 8 px |
| Shadow | `0 8px 24px rgba(0,0,0,0.12)` |
| Padding | 24 px |
| 배치 | 화면 중앙 정렬 |

### 9.6 예외 / 오류 상태

`Status-Error` (`#F94B50`) 보더 + 재시도 안내.
문구 예: 제목 `답변을 가져오지 못했습니다`, 본문 `일시적인 오류입니다. 잠시 후 다시 시도해주세요.`
응답 상태 세트: 생성 중 / 스트리밍 / 완료.

---

## 10. 아이콘

- 앱 공통 아이콘 세트(라인/필)를 사용. 사용자 경험 일관성 유지.
- 사용 위치·크기 고려. 시스템/서비스 Identity 에 따라 수정·추가 가능하되 Keyline 기반으로 시각 크기 일관성 유지.
- 전부 **Lined icon**, **20 × 20 px** 기본.

| 위치 | 컬러 |
|------|------|
| Favorites (Grey 타입) | Grey800 `#3C3E3D` |
| Favorites (Primary 타입) | White `#FFFFFF` |
| Left Menu — 메뉴 아이콘 | Grey900 `#1F1F1F` |
| Left Menu — 대화 고정(핀) | Grey500 `#979998` |
| Left Menu — 추가 기능 버튼 | Grey800 `#3C3E3D` |
| Tab (대화/프로젝트) 활성 | Grey900 `#1F1F1F` |
| Tab 비활성 | Grey600 `#6E706F` |

아이콘 네이밍 패턴: `Icons{Category}{Name}Appearance{Lined|Filled}`
(예: `IconsFunctionSearchAppearanceLined`, `IconsFileFolderAppearanceLined`, `IconsCommunicationConversationAppearanceLined`).

---

## 11. 적용 체크리스트

- [ ] 하드코딩 hex 대신 CSS 변수로 토큰화 (`--chat-primary-600: #2D9BB2` 등, 또는 `ui-design-tokens`) → chat CSS 상단
- [ ] 대화/콘텐츠 컨테이너 `max-width: 720px`
- [ ] 사용자 말풍선: 우측 정렬, `background Grey200`, `border-radius 16px 0 16px 16px`, `padding 12px 16px`
- [ ] **사용자·AI 말풍선 모두** MD + allowlist HTML 렌더 (`textContent` only 금지; 원시 `**`/`#` 보이면 실패)
- [ ] AI 답변: 배경 없음, 본문 14px/1.65, 링크는 Primary600 + underline. 본문·출처·액션은 세로. 가로 flex로 글자 쪼개기 금지
- [ ] 답변 하단 액션: 기본은 **복사·좋아요·싫어요** 아이콘만 (재생성·「더 짧게」등 텍스트 칩은 제품 정책에 따라 — 아래 §11.1)
- [ ] 출처 블록: 배경 Grey50, 문서명 16px Bold Grey850, URL Grey600
- [ ] Reasoning 블록: 배경 Grey100, radius 12px + **대기 중 spinner** (SSE 단계)
- [ ] 입력창: radius 20px, border 1px Grey300, 전송 원형 36px Primary600 (hover Primary700)
- [ ] 추천 질문 카드: Grey 또는 Mint 중 **하나만** 프로젝트 전체에 일관 적용
- [ ] 팝업: 중앙 정렬, radius 8px, dim `rgba(31,31,31,0.4)`, padding 24px, shadow `0 8px 24px rgba(0,0,0,0.12)`
- [ ] 서체 Pretendard / IBM Plex Sans KR 로드 (미로드 시 system-ui fallback)
- [ ] 가이드 외 색 신규 도입 금지 — 필요하면 Status/Support 팔레트에서 고를 것

### 11.1 ChatPage 잠금

제품 경로 예: `frontend/src/pages/ChatPage.tsx` · `styles/chat.css`.  
셸/계정/테마는 **`ui-governance/chat_shell_ui.md`** (있을 때)가 우선.

| 항목 | 잠금 |
|---|---|
| 세션 목록 우측 | 아이콘: 이름변경 · 삭제 · 고정(핀) |
| 메시지 액션 | 아이콘만: 복사 · 👍 · 👎. 한글 칩(더 짧게/자료/다시쓰기) **금지** |
| 대기 UX | SSE `reasoning`/`tool` + `.chat-spinner`. 빈 말풍선만 금지 |
| 외부 스튜디오 hop | 전용 open API로만. agent 응답으로 가로채기 금지 |
| 다크 | `#fff` 하드코딩 금지 — `--surface` / `--input-bg` |

---

## 12. 연계

- 색·간격 기본: `ui-design-tokens` / `ui-color-system`
- 타이포: `ui-typography`
- 챗 동작·세션·chitchat: `ui-governance/chat_ui.md` (있을 때)
- 파일 형식 칩: `ui-governance/file_type_icons.md`
