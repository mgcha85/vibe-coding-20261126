# detail

## 노드별 구현 스펙 (재작성 시 필수)

### 1) Context Loader v3

```
POST {$vars.API_BASE_URL}/api/v1/rag-memory/context
body: { sso_id, session_id }
→ state: user_memory(=API 응답 그대로), turn_count, session_summary,
         use_vector/use_external, current_topic,
         last_assistant_route, last_assistant_has_docs
```

세션 요약을 CustomFunction에서 다시 prepend하지 말 것 (API가 이미 unified MD 조립).

### 2) Re-retrieve Gate

- `user_selected` + 전체요약 정규식(+ EXTRACT_ONLY 제외) → `fast_route=file_summarize`
- 짧은 인사/감사 → `fast_route=chitchat`
- turn>1 + anaphora/topicOverlap + `last_assistant_has_docs` + route≠chitchat → `reuse`
- 그 외 → `fresh` / `continue`

### 3) Fast Path Gate

`$flow.state.fast_route`: `file_summarize` | `chitchat` | else→Rewriter.

### 4) Query Rewriter (`llmAgentflow`, temperature ~0.1)

입력: `$flow.state.user_memory` (Identity + MEMORY.md + Session Summary + Recent Turns ~5) + `{{question}}`.

**금지 (하드룰 추가 금지):** 대명사 체크리스트, graft 금지, 도메인 사고 예시(모로코 등)로 후속을 새 질문으로 리셋하지 않는다. 사고 한 건을 막으려 예외 규칙을 쌓지 않는다.

Rewriter는 그 맥락으로 **검색용 standalone 질의 한 줄**만 만든다. 후속·교정·범위 지정은 같은 스레드. 식별자 verbatim. Output ONLY rewritten query.

### 5) Adaptive Router (4 scenarios)

`chitchat` | `simple_rag` | `agentic_rag` | `file_summarize`  
대화 자체 요약 → chitchat. 선택 파일 전체 요약만 file_summarize.

### 6) Simple / Agentic RAG + 출처 Agent + CRAG

- Vector tool: `accessibleDocIds` allow-list + scope
- Agentic: CRAG → Loop max 2 → Query Rewriter
- 각 Agent: `last_assistant_answer` 기록

### 7) Document Summarizer

```
POST /api/v1/rag-memory/file-summarize
{ query, accessibleDocIds, accessibleDocIdsScope: "user_selected" }
```

scope/ids 없으면 안내 문구. short/echo 가드. `last_assistant_answer` 세팅.

### 8) Memory Updater v3

1. assistant 텍스트 = `last_assistant_answer` 우선; Citation-only JSON이면 버림
2. `POST /message` user + assistant
3. fire-and-forget `POST /extract-facts`
4. fire-and-forget `POST /session/auto-summarize` `{ threshold: 10 }`

**Merge:** outermost `findConditionParent` — 아니면 AND-deadlock으로 Memory 미실행 (LESSONS 2026-07-22).

---

## Backend API 최소 세트

마운트: `/api/v1/rag-memory`

| Method | Path | 누가 씀 |
|---|---|---|
| POST | `/context` | Context Loader v3 |
| POST | `/message` | Memory Updater v3 |
| POST | `/extract-facts` | Memory Updater (async) |
| POST | `/session/auto-summarize` | Memory Updater (async, every 10 user turns) |
| POST | `/file-summarize` | Document Summarizer |
| POST | `/fact`, `/facts/batch` | 수동/배치 |
| GET/PUT | `/memory-file/:ssoId` | MEMORY.md |
| DELETE | `/session/:sessionId`, `/user/:ssoId` | 정리 |

스키마·바디·프롬프트: `REFERENCE.md`.

---

## 재구현 / 반영 체크리스트

1. Oracle/SQLite 테이블 + `DATA_DIR`
2. `rag-memory` 라우터 등록 + **`fileSummarize` mount**
3. orchestrator variables: `API_BASE_URL` = self URL
4. Flow/그래프 변경 → consumer `PROJECT.md`에 정의된 flow SSoT에 커밋
5. 배포 → consumer CI (`infra-deploy-runner-github`) — flow import + restart
6. 서버 변경이면 rebuild + restart (수동 scp 금지)
7. 검증:
   - Turn 1: `/context` + message 저장
   - Turn ≥10: auto-summarize → 다음 context에 `## Session Summary`
   - 새 세션: MEMORY.md facts 유지
   - Memory Updater executedData 포함 (waiting 무한 X)
   - Rewriter topic pollution 없음
   - Citation 후 assistant 평문 persist

---

## 금지 / 함정

| 함정 | 대응 |
|---|---|
| Canvas만 수정 | 다음 import에 롤백 |
| build 스크립트만으로 regenerate | flow JSON 기능 소실 — diff 필수 |
| `ephemeralMemory: true`로 “멀티턴” | 본 구현과 반대 |
| Memory가 Citation JSON 저장 | `last_assistant_answer` 우선 |
| Query Rewriter에 대명사/graft 하드룰 재추가 | **금지** — Identity+MEMORY+최근 턴만 |
| 엑셀 재고 vs PR을 질문 키워드로 dump 필터 | **금지** — catalog + txt2sql/`duckdb_query` |
| merge AND deadlock | outermost `findConditionParent` |
| `accessibleDocIds` 소실 | `preserveRequestScopedState` |
| `user_facts` CLOB+UNIQUE | VARCHAR2(2000) |
| file-summarize 404 | `fileSummarize.ts` router mount |

---

## 변경 시 파일 맵

| 하고 싶은 일 | 수정 파일 |
|---|---|
| Loader 메모리 내용 | `contextMemoryMd.ts` + `/context` + Context Loader JS in flow JSON |
| 요약 주기/길이 | Memory Updater `threshold` + `sessionAutoSummarize.ts` |
| Rewrite 규칙 | Query Rewriter `llmMessages` in flow JSON |
| Reuse / fast path | Re-retrieve Gate + Fast Path Gate in flow JSON |
| 라우팅 라벨 | Adaptive Router scenarios |
| Fact 추출 | `FACT_EXTRACTION_PROMPT` |
| 전체 파일 요약 | Document Summarizer JS + `fileSummarize.ts` |
| Citation 루프 | Flowise `PROJECTS.md` §10 |

---

## 검증용 최소 시나리오

```
1) S1: "BIP가 뭐야?" → simple/agentic + 근거
2) S1: "그건 양도 가능해?" → Rewriter anaphora 해소
3) S1: "관세비가 있는 생산지는?" (이전 토픽 무관) → graft 없이 새 검색
4) S1: "안녕" → fast_route chitchat
5) user_selected + "이 문서 요약해줘" → Document Summarizer
6) S2 같은 sso: 관심 주제 → MEMORY.md facts
```

로그: `[Context Loader v3]`, `[Re-retrieve Gate]`, `[Document Summarizer]`, `[Memory Updater v3]`, `[RAG-Memory]`.


---

## 1. Topology (실제 노드)

```
Start
 ├─[uploads?] YES → Teams 업로드 → OK? → Keylook Ingest → Indexing Poller → 인덱싱 완료 응답 (END)
 │                           └─ fail → 실패 응답 → DirectReply (END)
 └─ NO → Context Loader v3
           → Re-retrieve Gate          # sets retrieval_mode, skip_retrieval, fast_route
           → Fast Path Gate            # condition on $flow.state.fast_route
                ├─ file_summarize → Document Summarizer ──────────────────┐
                ├─ chitchat       → Chitchat Fast ────────────────────────┤
                └─ continue       → Query Rewriter
                                      → Adaptive Router
                                           ├─ chitchat      → Chitchat ───┤
                                           ├─ simple_rag    → Simple RAG → 출처 Agent ─┤
                                           ├─ agentic_rag   → Agentic RAG → CRAG Evaluator
                                           │                     ├ sufficient → 출처 Agent ─┤
                                           │                     └ insufficient → CRAG Loop(≤2)
                                           │                           → back to Query Rewriter
                                           └─ file_summarize → Document Summarizer ─┤
                                                                                    ▼
                                                                         Memory Updater v3
```

Marketplace 표시명: **표준 RAG** / **표준 RAG v2**.  
내부 파일명: `personalized-rag-v3-flow.json`.

---

## 2. Backend: `/api/v1/rag-memory`

### Mount

- `consumer server package/src/routes/index.ts` → `router.use('/rag-memory', ragMemoryRouter)`
- 메인 구현: `consumer server package/src/routes/rag-memory/index.ts`
- 파일 전체 요약: `consumer server package/src/routes/rag-memory/fileSummarize.ts`  
  → **`index.ts`에서 `router.use(fileSummarizeRouter)` 등으로 mount 필수** (Document Summarizer가 `POST /file-summarize` 호출).

### Storage

| Backend | Path / table |
|---|---|
| SQLite (local) | `{DATA_DIR}/db/rag_memory.db` |
| MEMORY.md | `{DATA_DIR}/memory/{sso_id}/MEMORY.md` |
| Oracle | `ARF_FLOWISE_RAG_USER_FACTS`, `_USER_PROFILES`, `_SESSIONS`, `_MESSAGES` |

Logical → Oracle map (`RAG_TABLE_MAP`):

```
user_facts → ARF_FLOWISE_RAG_USER_FACTS
user_profiles → ARF_FLOWISE_RAG_USER_PROFILES
sessions → ARF_FLOWISE_RAG_SESSIONS
messages → ARF_FLOWISE_RAG_MESSAGES
```

**Oracle 제약:** `user_facts.content` = `VARCHAR2(2000)` + `UNIQUE(sso_id, content)`. CLOB+UNIQUE 금지.

### SQLite schema (핵심)

```sql
user_facts(id, sso_id, content, category, confidence, source_session, created_at, last_confirmed)
  UNIQUE(sso_id, content)
user_profiles(sso_id PK, display_name, interaction_count, first_seen, last_active, topics_of_interest)
sessions(session_id PK, sso_id, created_at, last_active, turn_count, current_topic, summary, metadata)
messages(id, session_id, sso_id, role, content, route, retrieved_docs, token_count, created_at)
```

`sessions.metadata` JSON 예: `{ "summary_user_turns": 10, "summary_updated_at": "..." }` — auto-summarize 게이트용.

---

## 3. API contracts

### POST `/context` — Context Loader v3

**Body:** `{ sso_id, session_id }` (둘 다 required)

**Side effects:** `upsertSession`, `upsertProfile`, Identity fetch (`ARF_BASE_URL` directory).

**Response (핵심):**

```json
{
  "sso_id": "...",
  "session_id": "...",
  "user_memory": "<unified MD>",
  "context_md": "<same>",
  "identity": { "user_nm", "jps_nm", "org_nm", ... } | null,
  "facts": [{ "content", "category", "confidence" }],
  "messages": [{ "role", "content", "route", "created_at" }],
  "session": { "turn_count", "current_topic", "summary" },
  "profile": { "interaction_count", "topics_of_interest" }
}
```

`user_memory` 조립 (`contextMemoryMd.ts` + Identity):

1. Cross-session: MEMORY.md (있으면) else facts bullet list → `## Identity` 블록 merge
2. `## Session Summary` (sessions.summary, ≤800)
3. `## Recent Turns` — 최근 **5 user turns** (+ 끼어 있는 assistant), 각 메시지 ≤800자

### POST `/message` — Memory Updater

**Body:** `{ session_id, sso_id, role, content, route?, retrieved_docs?, token_count?, current_topic? }`

- user + assistant 각각 1회 호출
- `current_topic`은 assistant 저장 시 sessions 갱신에 사용 (보통 `query_rewrite`)

### POST `/extract-facts` — async

**Body:** `{ sso_id, session_id?, user_input, assistant_response? }`

- LLM (`LLM_BASE_URL`/`LLM_MODEL_NAME`, `chat_template_kwargs.enable_thinking: false`)
- 출력: `[{"content","category":"role|preference|topic|skill","confidence"}]`
- 단발 문서 Q&A 토픽은 fact로 저장 금지 (프롬프트 규칙)
- upsert → `syncMemoryFile(sso_id)`

### POST `/session/auto-summarize`

**Body:** `{ session_id, sso_id?, threshold? }`  
기본 `threshold=10` (`DEFAULT_SUMMARY_THRESHOLD`). Memory Updater는 **threshold: 10** 고정 호출.

게이트 (`sessionAutoSummarize.ts`):

- user 메시지 수 < threshold → `skipped: below_threshold`
- `userTurns - last_summarized_user_turns < threshold` → `skipped: not_due`
- else: prior summary + 최근 `threshold*2` messages → LLM → clamp ≤800 → UPDATE sessions.summary + metadata

### POST `/file-summarize` — Document Summarizer

**Body:** `{ query, accessibleDocIds[], accessibleDocIdsScope, collection_alias? }`

- `accessibleDocIdsScope === "user_selected"` + non-empty ids 필수
- Keylook `document_content` fetch → stuff / map-reduce (`flowise-components`)
- Response: `{ summary, docs: [{ method, chunkCount, ... }] }`

### 기타

| Method | Path | 용도 |
|---|---|---|
| POST | `/fact`, `/facts/batch` | 수동 fact |
| GET | `/facts/:ssoId`, `/sessions/:ssoId` | 조회 |
| POST | `/session/summary` | 수동 summary set |
| GET/PUT | `/memory-file/:ssoId` | MEMORY.md |
| DELETE | `/session/:sessionId`, `/user/:ssoId`, `/fact/:factId` | 정리 |
| POST | `/cleanup` | 만료 |
| GET | `/stats` | 카운트 |
| DELETE | `/vectordb/purge` | Keylook purge (별도) |

---

## 4. Flow CustomFunction / LLM (flow JSON 스냅샷)

### Context Loader v3 → state

```
sso_id, user_memory, turn_count, session_summary,
use_vector, use_external, loop_count,
current_topic, last_assistant_route, last_assistant_has_docs
```

- API `user_memory`를 **그대로** 사용 (세션 요약 이중 wrap 금지 — 과거 버그).

### Re-retrieve Gate → state

`retrieval_mode`, `skip_retrieval`, `fast_route`

| 조건 | 결과 |
|---|---|
| `user_selected` + 짧은 전체요약 정규식 + EXTRACT_ONLY 아님 | `fast_route=file_summarize`, skip_retrieval |
| 짧은 인사/감사 CHITCHAT_RE | `fast_route=chitchat` |
| turn≤1 | `fresh`, `fast_route=continue` |
| anaphora/topicOverlap + prior docs + last route≠chitchat | `reuse`, skip_retrieval |
| else | `fresh`, `continue` |

**Reuse 금지:** `last_assistant_has_docs !== "true"`.

### Fast Path Gate

`$flow.state.fast_route` equal:

- `file_summarize` → Document Summarizer
- `chitchat` → Chitchat Fast
- else → Query Rewriter

### Query Rewriter

입력: `user_memory` (Identity + MEMORY.md + Session Summary + Recent Turns ~5) + latest message.

**하드룰 금지:** 대명사 체크리스트 / graft 금지 / 도메인 사고 예시로 후속을 새 질문 처리하지 않음.

검색용 standalone 질의 한 줄. 후속·교정·범위 지정은 같은 스레드. 식별자 verbatim. Output ONLY rewritten query.

`llmUpdateState`: `query_rewrite = {{ output }}`  
`temperature: 0.1`

### Adaptive Router scenarios (4)

1. `chitchat` — 잡담/날짜/Identity/대화 요약
2. `simple_rag` — 단일 검색
3. `agentic_rag` — 다단계/비교/합성
4. `file_summarize` — user_selected 전체 파일 요약 (토픽성 “요약” 단어만으로 선택 금지)

대화 요약(“지금까지 대화 정리”) → **chitchat** (file_summarize 아님).

### Agents

공통 multiturn (Simple/Agentic/Chitchat Fast):

- 지금 질문에 답한다. Identity / MEMORY.md / 세션 요약 / 최근 턴은 대화 맥락이다.
- Final answer language: `{{$vars.answerLanguage}}` (default: ko; ARF overrideConfig.vars)
- Source docs may be KO; translate final synthesis only; citations stay `[title](url) (p.N)`
- Query Rewriter search query stays **Korean** (KO corpus) even if user wrote EN/ZH/PL
- `agentUpdateState`: `route_decision` + **`last_assistant_answer: {{ output }}`**

| Agent | Force tool | Max iter | Tools |
|---|---|---|---|
| Chitchat / Chitchat Fast | false | 3 | current_date_time |
| Simple RAG | true | 2 | personal_vector_search, external_search |
| Agentic RAG | true | (higher) | same + CRAG loop |

`skip_retrieval=true` + `reuse` → Simple은 검색 없이 메모리로 답 (새 문서 요청 시만 검색).

### Document Summarizer

- POST `/file-summarize` with state ids/scope + `answerLanguage` (`$vars.answerLanguage`, default ko)
- short/echo guard: len&lt;150 or title-echo → 사용자 안내 메시지
- `agentUpdateState` 동등: `route_decision=file_summarize`, `last_assistant_answer`

### Memory Updater v3

1. `last_assistant_answer` 우선 (Citation JSON이면 discard)
2. fallback `$flow.output` — citation-only면 빈 문자열, assistant persist skip
3. POST `/message` user + (optional) assistant
4. fire-and-forget `/extract-facts`
5. fire-and-forget `/session/auto-summarize` `{ threshold: 10 }`
6. return `agentResponse` (사용자에게 보이는 최종 텍스트)

---

## 5. Runtime glue (서버)

### SSO → state

`buildAgentflow.ts`: `X-SSO-ID` → `$flow.state.sso_id` / `$flow.ssoId`.

### Request-scoped state

```ts
REQUEST_SCOPED_STATE_KEYS = ['accessibleDocIds', 'accessibleDocIdsScope']
preserveRequestScopedState(previous, next)  // 매 노드 state merge
```

overrideConfig.vars에서 lift. RAG tool은 scope=`user_selected`일 때 allow-list 강제.

### Merge deadlock fix

`agentflowConditionParent.ts` — `findConditionParent` = **outermost** condition ancestor.  
Simple RAG / CRAG / Document Summarizer / Chitchat 가 Citation·Memory로 합류할 때 동일 그룹이어야 함.  
(LESSONS: nested AND → Memory Updater 미실행)

---

## 6. Env checklist

```
DATA_DIR=...
LLM_BASE_URL=...
LLM_MODEL_NAME=...
LLM_API_KEY=...
ARF_BASE_URL=...                 # Identity
# orchestrator variables:
API_BASE_URL=http://localhost:8000   # or deployed self URL
KL_COLLECTION_ALIAS=...              # Document Summarizer optional
```

Flow placeholders (`@@LLM_*@@`, `@@TEAMS_API_URL@@`, …): `scripts/flow-placeholders.js` + `consumer flow import (PROJECT.md)`.

---

## 7. Edit / deploy map

| 변경 | 파일 | 배포 |
|---|---|---|
| 오케스트레이터 노드 / prompts / edges | consumer flow SSoT (`PROJECT.md`) | CI flow import |
| `/context` MD shape | `contextMemoryMd.ts`, `directoryIdentity.ts`, rag-memory `/context` | server rebuild + restart |
| summarize cadence | Memory Updater JS `threshold` + `sessionAutoSummarize.ts` | flow + server |
| fact rules | `FACT_EXTRACTION_PROMPT` in rag-memory | server |
| merge waiting | `agentflowConditionParent.ts` | server |
| citation loop | Flowise `PROJECTS.md` §10 | flow + components |
| Knowledge ingest/search | consumer knowledge store | — |

**금지:** Canvas만 저장 / bare `pnpm build`로 dist 덮어쓰기 / scp 수동 배포 (infra-deploy-runner-github).

---

## 8. Debug checklist

1. Prediction `agentFlowExecutedData`에 **Memory Updater v3** 포함?
2. `POST /rag-memory/message` 후 messages count > 0?
3. Turn 10+ 후 `/context`에 `## Session Summary`?
4. Rewriter: 후속·교정이 최근 턴 엔티티를 유지하는지 (하드룰/대명사 체크로 리셋하지 말 것)
5. Citation 경로: `last_assistant_answer`가 평문인지 (JSON `citationsMarkdown`만 저장되면 안 됨)
6. Fast path: `fast_route` state + Fast Path Gate branch
7. `accessibleDocIds`가 Agentic 중간 노드 이후에도 유지되는지

로그 prefix: `[Context Loader v3]`, `[Re-retrieve Gate]`, `[Document Summarizer]`, `[Memory Updater v3]`, `[RAG-Memory]`, `[file-summarize]`.

---

## 9. Flowise consumer (RAG-bot)

Flowise fork에서 **표준 RAG / personalized-rag-v3** canvas·서버를 고칠 때만. 방법론은 본 REFERENCE §1–8과 동일.

### Source of truth (우선순위)

| 우선 | 역할 | 경로 (RAG-bot / Flowise 레포) |
|---|---|---|
| 1 | Flow JSON (배포 import) | `flows/personalized-rag-v3-flow.json` |
| 1 | Marketplace 동기본 | `packages/server/marketplaces/agentflowsv2/표준 RAG.json` (+ v2) |
| 2 | Backend API | `packages/server/src/routes/rag-memory/index.ts` |
| 2 | File summarize | `packages/server/src/routes/rag-memory/fileSummarize.ts` (**router mount 필수**) |
| 2 | unified `user_memory` MD | `packages/server/src/utils/contextMemoryMd.ts` |
| 2 | session auto-summarize | `packages/server/src/utils/sessionAutoSummarize.ts` |
| 2 | ARF Identity | `packages/server/src/utils/directoryIdentity.ts` |
| 2 | request-scoped state | `packages/server/src/utils/buildAgentflow.ts` (`preserveRequestScopedState`) |
| 2 | merge 조건 부모 | `packages/server/src/utils/agentflowConditionParent.ts` (outermost) |
| 3 | Flow 빌더 (부분·구버전) | `scripts/build-personalized-rag-v3-flow.js` |
| — | 설계 배경 | `docs/multiturn-rag-agentflow-design.md` |

Canvas만 저장하면 다음 `import-flows.js`가 git JSON으로 덮어씀.  
**`build-personalized-rag-v3-flow.js`만으로 regenerate 금지** — flow JSON 직접 수정(또는 스크립트 동기화 후 diff 검증).

### Flowise 배포 체크리스트

1. Flow JSON (+ marketplace) 커밋
2. `git push origin main` → Actions `import-flows.js` `[OK] Updated ...`
3. 서버 변경 시 rebuild + restart (`infra-deploy-runner-github`, 수동 scp 금지)
4. Flowise Variables: `API_BASE_URL` = self URL
5. Knowledge ingest/검색 → **consumer knowledge store** (프로젝트 `PROJECT.md`)

### `$flow.state` 계약

§4 Flow CustomFunction과 동일. `accessibleDocIds` / `accessibleDocIdsScope`는 overrideConfig.vars → **request-scoped** (`preserveRequestScopedState`).
