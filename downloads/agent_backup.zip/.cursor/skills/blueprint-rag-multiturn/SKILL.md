---
name: blueprint-rag-multiturn
description: >-
  멀티턴 RAG 방법론 — rag-memory 백엔드, Context Loader, Re-retrieve/Fast Path,
  Query Rewriter, Adaptive Router, CRAG, Document Summarizer, Memory Updater,
  session/cross-session MEMORY.md. 오케스트레이터(Flowise 등) 무관.
---

# 멀티턴 RAG (방법론 SSoT)

**플랫폼 중립.** 세션·기억·검색 게이트는 **`/api/v1/rag-memory/*`** + 통합 `user_memory` MD.  
벡터 검색·ingest → **consumer knowledge store** (프로젝트 `PROJECT.md` 계약). 오케스트레이터·출처·tool loop도 consumer 문서.

구현 경로·flow JSON·배포는 **consumer `PROJECT.md`**.  
오케스트레이터 consumer 패턴 → **[REFERENCE.md §9](REFERENCE.md#9-flowise-consumer-rag-bot)**.

상세 스키마·API·단계별 스펙: **[REFERENCE.md](REFERENCE.md)**

**프롬프트 하드룰 금지 (강력):** Query Rewriter / Agent에 대명사 체크리스트·graft 금지·도메인 사고 예시(모로코 등)로 멀티턴 예외 처리 금지. 맥락 = Identity + MEMORY.md + 세션 요약 + 최근 턴뿐.

## 파이프라인 (한 장)

```
SSO + sessionId
        │
        ▼
 uploads? ──YES──► 파일 업로드 → KL ingest → indexing 폴링 → 직접 응답 (END)
        │
        NO ──► Context Loader ──► Re-retrieve Gate ──► Fast Path Gate
                    │                      │
                    │                      ├─ file_summarize → Document Summarizer
                    │                      ├─ chitchat → Chitchat
                    │                      └─ continue → Query Rewriter → Adaptive Router
                    │                                        ├─ chitchat / simple_rag / agentic_rag / file_summarize
                    │                                        └─ CRAG loop (≤2) → Rewriter
                    ▼
              Memory Updater (message + async extract-facts + session auto-summarize)
```

**원칙:** 프레임워크 내장 short memory만으로 멀티턴을 대체하지 않는다. 장기/세션 컨텍스트는 **rag-memory API**가 조립한 `user_memory`.

챗 UI 잡담 short-circuit(규칙 우선·sources/trail 슬림·general만)는 오케스트레이터 노드가 아니라 **`ui-governance/chat_ui.md` «Chitchat»** 가 정본. 본 스킬의 `fast_route=chitchat` 와 의도만 맞춘다.

## 필수 환경 (패턴)

| 항목 | 용도 |
|------|------|
| `DATA_DIR` | `rag_memory.db`, `memory/{user_id}/MEMORY.md` |
| LLM env | fact extract, auto-summarize, 라우터/리라이터 |
| API base (self) | 오케스트레이터가 rag-memory 콜백 |
| Identity | `user_id` / 세션 주체 |
| Knowledge env | consumer vectordb / ingest (프로젝트 계약) |

DB: SQLite 기본, 기타 RDB는 consumer 스키마(REFERENCE).

## 연계

| 스킬 | 역할 |
|------|------|
| consumer knowledge | vectordb 검색·ingest·폴링 |
| `ui-chat` / `ui-governance` | 챗 UI · chitchat 표시 |
| `blueprint-ragas-eval` | RAG 품질 평가 |
