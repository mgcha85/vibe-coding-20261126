---
name: ui-chrome
description: Site chrome for the Astro lab — icon header nav (SiteNav), footer (SiteFooter), and SVG icon assets. Use when editing header/footer, routes in chrome, or icons under frontend/src/assets/icons. Formerly ui-navigation + ui-footer. For page grid see ui-layout-grid; for methods algo icons usage see ui-methods-explain.
---

# UI Chrome

`BaseLayout`의 **헤더 + 푸터**와 공유 SVG 아이콘을 한곳에서 관리한다.

| Piece | Component |
| --- | --- |
| Header | `SiteNav.astro` + `Icon.astro` |
| Footer | `SiteFooter.astro` |
| Icons | `frontend/src/assets/icons/{nav,algo}/` |

## Header (icon nav)

**아이콘 기본 + hover/focus(및 현재 페이지) 시 전체 이름.**

| href | full name (hover) | icon asset |
| --- | --- | --- |
| `/` | 개요 | `nav/overview.svg` |
| `/methods` | 분석 방법 | `nav/methods.svg` |
| `/eda` | 탐색 (EDA) | `nav/eda.svg` |
| `/qc` | 품질 관리 | `nav/qc.svg` |
| `/umap` | UMAP 군집 | `nav/umap.svg` |
| `/markers` | 마커·차별 발현 | `nav/markers.svg` |
| `/celltypes` | 세포 유형 | `nav/celltypes.svg` |

동작:

- 기본: 아이콘만 (현재 페이지는 이름 항상 표시)
- `:hover` / `:focus-visible`: 전체 이름 펼침
- `aria-label`에 full name 유지

## Footer

모든 페이지 하단. **브랜드 한 줄 · 데이터 안내 · © 연도**만.

1. Light elevated surface; top border only
2. 방문객 카피: 한국어, 스택명·C4 금지
3. viz stage와 경쟁하지 않음
4. shell flex + `margin-top: auto`로 짧은 페이지도 하단 고정
5. 바로가기 링크·“샘플 푸터” 문구 **넣지 않음** (라우트는 헤더만)
6. **새 primary 라우트** → `SiteNav` 표 + 이 문서 헤더 표만 갱신

## Icon assets

```
frontend/src/assets/icons/
├── nav/      # header (24×24, currentColor)
├── algo/     # /methods algorithm explain chips
└── methods/  # /methods who-story (person → data → analyze → result)
```

1. SVG만 (PNG/이모지 내비 금지)
2. `currentColor` stroke/fill
3. `Icon.astro`로 인라인 (`name="nav/overview"`) — `<img>` 금지
4. 카탈로그 → [REFERENCE.md](REFERENCE.md)

## Related

- `ui-astro-app` — BaseLayout wiring
- `ui-layout-grid` — page frame
- `ui-methods-explain` — where algo icons appear
- `ui-design-tokens` — colors / spacing
