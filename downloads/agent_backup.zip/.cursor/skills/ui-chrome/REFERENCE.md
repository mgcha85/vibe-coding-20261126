# Chrome icon asset catalog

(Former `ui-navigation` REFERENCE.)

## Nav icons (`src/assets/icons/nav/`)

| File | Metaphor |
| --- | --- |
| `overview.svg` | 2×2 tiles — lab overview |
| `raw.svg` | table grid — per-cell raw metrics |
| `methods.svg` | open notebook — analysis methods |
| `eda.svg` | bar chart — exploratory overview |
| `qc.svg` | funnel — quality filter |
| `umap.svg` | scatter on axes — UMAP |
| `markers.svg` | sized dots — marker panel / DEG |
| `celltypes.svg` | cell + label lines — cell types |

## Algorithm icons (`src/assets/icons/algo/`)

Used by `MethodsAlgoIcons.astro` on `/methods`.

| File | Concept (KO) | One-line idea |
| --- | --- | --- |
| `ingest.svg` | 적재 | 원시 행렬 → 표 |
| `qc-filter.svg` | 품질 필터 | 나쁜 세포 걸러내기 |
| `normalize.svg` | 정규화 | 세포 총량 맞추기 |
| `hvg.svg` | 고변동 유전자 | 변동 큰 유전자 선택 |
| `pca.svg` | PCA | 주성분으로 압축 |
| `neighbors.svg` | 이웃 그래프 | 비슷한 세포 연결 |
| `umap.svg` | UMAP | 2D 배치 |
| `leiden.svg` | Leiden | 커뮤니티 = 무리 |
| `deg.svg` | 차별 발현 | 무리별 순위 유전자 |
| `panel.svg` | 마커 패널 | 알려진 마커 평균 |
| `annotate.svg` | 유형 판정 | 마커 → 세포 유형 |
| `export.svg` | 내보내기 | 화면용 스냅샷 |

## Methods story icons (`src/assets/icons/methods/`)

Used by `/methods` 「누가 무엇을 보나」 board.

| File | Role |
| --- | --- |
| `person.svg` | 연구자 |
| `dataset.svg` | 공개 데이터 |
| `analyze.svg` | 분석 과정 |
| `result.svg` | 결과 |

## Adding an icon

1. Draw 24×24 SVG with `currentColor`.
2. Save under `nav/`, `algo/`, or `methods/`.
3. Reference via `<Icon name="nav/…" />` (etc.).
4. Update this table + `SKILL.md` route lists if chrome routes change.
