---
name: ui-echarts
description: Mandates Apache ECharts as the only charting library for Astro lab visualizations. Use when adding or changing any plot, installing chart deps, or choosing between SVG/custom canvas and ECharts. For chart-specific encodings see ui-viz-*; for tokens see ui-design-tokens.
---

# UI ECharts (SSoT)

이 프로젝트의 **모든 연구용 차트는 Apache ECharts**로 그린다.

## Rules

1. Allowed: `echarts` (tree-shake via `echarts/core` + charts/components/renderers). Shared bootstrap: `frontend/src/lib/echarts-setup.ts`.
2. Forbidden as page deliverables: hand-rolled SVG/canvas charts, Chart.js, Plotly, Observable Plot, LayerChart, matplotlib/seaborn PNG embeds (debug under `results/` only).
3. **Methods explain boards** on `/methods` use semantic HTML/CSS (who/what, data-flow, schematic, funnel, timeline) via `ui-methods-explain` — not Mermaid, not circle-only graphs, not ECharts. Visitor copy: no C4 level names or stack callouts. Result plots (QC/UMAP/markers) stay ECharts-only.
4. Light theme: `backgroundColor: 'transparent'`; axis/series colors from CSS variables (`ui-design-tokens`).
5. Data still comes only from `frontend/public/data/*.json` — ECharts does not talk to DuckDB.
6. Violin has no built-in series → use ECharts `custom` series (KDE polygon) or an official ECharts custom-series addon if pinned; do not fall back to raw SVG components.
7. Prefer `large: true` on dense scatters (UMAP).

## Component map

| Page | Component | ECharts types |
| --- | --- | --- |
| `/qc` | `QcCharts.astro` | `bar` + `markLine` |
| `/umap` | `UmapChart.astro` | `scatter` (per Leiden) |
| `/markers` | `MarkerDotPlot.astro` | `scatter` + `visualMap` |
| `/markers` | `MarkerViolin.astro` | `custom` violin polygons |
