---
name: ui-typography
description: Modular type scale for Astro lab pages. Use when setting headings, body, mono for gene names, or caption styles. Adapted from Owl-Listener designer-skills typography-scale. For tokens file use ui-design-tokens.
---

# UI Typography

Adapted from designer-skills `typography-scale`.

## Scale

| Role | Size | Weight | LH |
| --- | --- | --- | --- |
| Display | 40px | 700 | 1.2 |
| H1 | 32px | 700 | 1.2 |
| H2 | 24px | 600 | 1.25 |
| H3 | 20px | 600 | 1.3 |
| Body | 16px | 400 | 1.5 |
| Small | 14px | 400 | 1.45 |
| Caption | 12px | 500 | 1.4 |

## Families

- Sans: Pretendard / IBM Plex Sans KR (UI·본문)
- Mono: IBM Plex Mono (gene symbols, barcode, stats)

## Rules

- Gene names always mono + tabular where possible
- Page title one H1; section one H2
- Avoid Inter/Roboto/Arial as primary brand face
- Korean copy: no mixed random English status chips
