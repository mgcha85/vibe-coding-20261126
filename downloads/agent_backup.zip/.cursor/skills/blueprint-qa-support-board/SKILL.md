---
name: blueprint-qa-support-board
description: >-
  사내 웹 서비스에 붙이는 사용자 문의 게시판(1:1 왕복 Q&A + AI 초안 답변) 패턴.
  SQLite 스레드/메시지 모델, owner/admin 서버측 인가, 백그라운드 AI 초안,
  관리자 rename/delete/요약. proposal-pilot /api/board 참고 구현. 문의 게시판,
  Q&A board, AI 초안 답변, 고객센터 패턴 언급 시.
---

# Blueprint: QA Support Board (사용자 문의 게시판)

사내 서비스에 「사용자 문의 → 관리자 답변」 1:1 왕복 게시판를 붙이는 재사용 패턴.
참고 구현: proposal-pilot `backend/src/board.rs` + `backend/src/board_routes.rs` + `src/routes/board/+page.svelte` (관리자 rename/delete 포함, commit c4f3b72).

## 핵심 설계 결정

| 결정 | 이유 |
|---|---|
| 스레드 = 1:1 왕복 (공개 게시판 아님) | 상세 조회 `author_sso == 세션 sso_id || admin`만. 목록도 사용자 본인 것만 |
| 상태 = 메시지 sender에서 파생 | 마지막 USER → `OPEN`, ADMIN → `ANSWERED`. 별도 종결 상태·메일 알림 없음(YAGNI) |
| AI 초안은 `board_messages.ai_draft` 컬럼 | USER 메시지에만 붙음. **사용자 응답 직렬화에서 절대 제외** — 관리자만 응답 본문으로 사용 |
| AI 초안 생성은 백그라운드 spawn | 문의 등록 응답을 블로킹하지 않음. 실패는 `ai_draft_status=FAILED`로 두고 등록은 성공 |
| 관리자 관리 버튼 | 목록/상세에서 rename·delete (admin 전용 API + FE 버튼) |

## 데이터 모델 (SQLite, init_db에 CREATE TABLE IF NOT EXISTS)

```
board_threads:   id TEXT PK, author_sso TEXT, title TEXT,
                 status TEXT('OPEN'|'ANSWERED'), created_at, updated_at
board_messages:  id TEXT PK, thread_id FK, sender TEXT('USER'|'ADMIN'), body TEXT,
                 ai_draft TEXT NULL, ai_draft_status TEXT NULL('PENDING'|'DONE'|'FAILED'),
                 created_at
```

## API (prefix `/api/board`)

| 메서드/경로 | 인가 | 동작 |
|---|---|---|
| GET `/threads` | user | admin=전체 / user=본인만. status·updated_at 내림차순 |
| POST `/threads` | user | `{title, body}` → 백그라운드 AI 초안 spawn |
| GET `/threads/:id` | owner-or-admin | admin만 `aiDraft` 포함, 아니면 키 자체 0회 |
| POST `/threads/:id/messages` | owner | 재질문 → 초안 재생성 spawn |
| POST `/admin/threads/:id/replies` | admin | 답변 → ANSWERED |
| POST `/admin/threads/:id/draft` | admin | 초안 동기 재생성(결과 반환) |
| POST `/admin/threads/:id/rename` | admin | `{title}` 제목 변경 |
| DELETE `/admin/threads/:id` | admin | 스레드+메시지 삭제 |
| GET `/admin/summary` | admin | `{waiting: N}` 배지용 대기 건수 |

## 인가 규칙 (harness-secure-coding 준수)

- 모든 핸들러 첫 줄 `require_user`/`require_admin` — **서버측** 검증. FE 숨김만으로는 불충분.
- owner 검증 실패는 403 아닌 **404** (존재 여부 노출 방지).
- SQL 전부 파라미터 바인딩(rusqlite params). 신규 의존성 없음.

## AI 초안 프롬프트 골격

시스템: 「사내 AI 플랫폼 문의 답변 도우미, 한국어, 정중하게」 + 스레드 기존 메시지 + 새 질문.
`last_user_question()`이 해당 질문 이전 히스토리를 컨텍스트로 반환. 응답은 JSON `{...}` 추출(시작/끝 중괄호).

## 회귀 테스트 (board.rs tests)

- open→answered→reopen 상태 전이
- 사용자 뷰에 `ai_draft` 절대 미포함
- `set_draft`가 USER 메시지만 갱신
- 목록 author 필터 격리

## 배포 후 스모크 (dev)

```
무세션 GET /api/board/threads        → 401
무세션 GET /api/board/admin/summary  → 403
비관리자 타인 thread 상세            → 404
글 작성 → 5초 내 초안 PENDING→DONE
관리자 답변 → ANSWERED 전이
```

## 연계

| 스킬 | 역할 |
|---|---|
| `harness-secure-coding` | 인가 게이트·Deploy gate |
| `security-review-pack` | 제출용 보안성검토 |
| `infra-deploy-awx` | BE release 바이너리 배포 채널 |
