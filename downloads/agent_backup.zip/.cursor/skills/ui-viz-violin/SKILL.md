---
name: ui-viz-violin
description: Astro stacked violin plots for marker genes by Leiden using Apache ECharts custom series. Use when showing per-cluster expression on /markers. For ECharts rules use ui-echarts; for backend means use data-analytics-markers.
---

# UI Viz Violin

**Chart library: Apache ECharts only** (`ui-echarts`).

## Chart

- One ECharts instance, multiple `grid` rows (one gene each)
- Density via client KDE → ECharts `custom` series polygons (or pinned official custom-violin addon)
- Fill uses `--cluster-N` at low opacity

## Data

`marker_violin.json` sampled/log-normalized points. Do not ship full COO counts.

## Anti-patterns

Standalone SVG violin components outside ECharts; non-ECharts chart libraries.
