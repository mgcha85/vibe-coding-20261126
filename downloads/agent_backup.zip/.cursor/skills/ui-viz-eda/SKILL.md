---
name: ui-viz-eda
description: Astro /eda exploratory charts (library-size hist, genes×counts scatter, top genes) via Apache ECharts. Use when building the EDA page. Data from data-analytics-eda; ECharts rules in ui-echarts.
---

# UI Viz EDA

**Chart library: Apache ECharts only.**

## Required views (`/eda`)

1. Summary strip — cells / genes / nnz / sparsity / median library size
2. Scatter — `total_counts` × `n_genes_by_counts` (color by keep)
3. Histogram — library size (`total_counts`), category-axis wide bars (same rule as `ui-viz-qc`)
4. Horizontal bar — top genes by total counts
5. Detection ladder — genes in ≥k cells (bar or simple strip)

## Data

`public/data/eda_summary.json`, `eda_cells.json`

## Anti-patterns

Value-axis skinny histogram sticks; matplotlib PNG; stacking names in visitor copy.
