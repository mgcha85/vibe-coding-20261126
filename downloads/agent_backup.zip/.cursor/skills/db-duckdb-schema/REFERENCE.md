# DuckDB DDL Reference

```sql
CREATE TABLE IF NOT EXISTS genes (
  gene_symbol VARCHAR PRIMARY KEY,
  gene_id VARCHAR,
  is_mt BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS cells_raw (
  barcode VARCHAR PRIMARY KEY,
  n_genes_by_counts INTEGER,
  total_counts DOUBLE,
  pct_counts_mt DOUBLE
);

-- Non-zero raw counts only
CREATE TABLE IF NOT EXISTS counts (
  barcode VARCHAR NOT NULL,
  gene_symbol VARCHAR NOT NULL,
  count DOUBLE NOT NULL,
  PRIMARY KEY (barcode, gene_symbol)
);

CREATE TABLE IF NOT EXISTS cells_qc (
  barcode VARCHAR PRIMARY KEY,
  n_genes_by_counts INTEGER,
  total_counts DOUBLE,
  pct_counts_mt DOUBLE,
  keep BOOLEAN NOT NULL
);

CREATE TABLE IF NOT EXISTS cells_filtered AS
  SELECT * FROM cells_qc WHERE keep; -- materialize in qc stage

CREATE TABLE IF NOT EXISTS embeddings_umap (
  barcode VARCHAR PRIMARY KEY,
  umap_1 DOUBLE NOT NULL,
  umap_2 DOUBLE NOT NULL
);

CREATE TABLE IF NOT EXISTS clusters (
  barcode VARCHAR PRIMARY KEY,
  leiden VARCHAR NOT NULL
);

CREATE TABLE IF NOT EXISTS markers (
  leiden VARCHAR NOT NULL,
  gene_symbol VARCHAR NOT NULL,
  scores DOUBLE,
  logfoldchanges DOUBLE,
  pvals DOUBLE,
  pvals_adj DOUBLE,
  rank INTEGER NOT NULL,
  PRIMARY KEY (leiden, gene_symbol)
);

CREATE TABLE IF NOT EXISTS marker_means (
  leiden VARCHAR NOT NULL,
  gene_symbol VARCHAR NOT NULL,
  mean_expr DOUBLE NOT NULL,
  PRIMARY KEY (leiden, gene_symbol)
);

CREATE TABLE IF NOT EXISTS celltypes (
  leiden VARCHAR PRIMARY KEY,
  n_cells INTEGER NOT NULL,
  label VARCHAR NOT NULL,
  confidence VARCHAR NOT NULL, -- high|medium|low
  evidence_json VARCHAR NOT NULL,
  rejected_alt VARCHAR
);

CREATE TABLE IF NOT EXISTS pipeline_runs (
  run_id VARCHAR NOT NULL,
  stage VARCHAR NOT NULL,
  params_json VARCHAR NOT NULL,
  started_at TIMESTAMP NOT NULL,
  finished_at TIMESTAMP,
  status VARCHAR NOT NULL,
  PRIMARY KEY (run_id, stage)
);
```

## Index hints

```sql
CREATE INDEX IF NOT EXISTS idx_counts_gene ON counts(gene_symbol);
CREATE INDEX IF NOT EXISTS idx_clusters_leiden ON clusters(leiden);
CREATE INDEX IF NOT EXISTS idx_markers_leiden ON markers(leiden, rank);
```
