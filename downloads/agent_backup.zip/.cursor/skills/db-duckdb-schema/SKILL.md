---
name: db-duckdb-schema
description: Owns DuckDB table contracts for the PBMC3k warehouse. Use when creating or altering tables, writing DDL, or deciding what belongs in DuckDB vs AnnData. For loading h5ad use db-ingest-h5ad; for SELECT patterns use db-query-patterns.
---

# DB DuckDB Schema

`data/warehouse/pbmc3k.duckdb`가 표 데이터의 SSOT다. 스키마 변경은 이 스킬의 DDL을 먼저 갱신한 뒤 코드에 반영한다.

## Core tables

| Table | Grain | Written by |
| --- | --- | --- |
| `genes` | gene_symbol | ingest |
| `cells_raw` | barcode | ingest |
| `counts` | (barcode, gene_symbol) nonzero | ingest |
| `cells_qc` | barcode (+ qc cols, `keep` bool) | qc |
| `cells_filtered` | barcode surviving QC | qc |
| `embeddings_umap` | barcode, umap_1, umap_2 | cluster |
| `clusters` | barcode, leiden | cluster |
| `markers` | cluster, gene, rank metrics | markers |
| `marker_means` | cluster × gene panel | markers |
| `celltypes` | cluster, label, confidence | annotate |
| `pipeline_runs` | run_id, stage, params_json, ts | all stages |

## Rules

1. Counts는 **COO long format**만 저장한다 (dense 행렬 금지).
2. AnnData는 디스크 SSOT가 아니다. 그래프 단계 임시 객체.
3. `CREATE OR REPLACE`는 stage 소유 테이블에만. raw ingest 테이블을 QC가 drop하지 않는다.
4. 타입: barcode/gene `VARCHAR`, counts `INTEGER`/`DOUBLE`, flags `BOOLEAN`.

DDL 전문은 [REFERENCE.md](REFERENCE.md).
