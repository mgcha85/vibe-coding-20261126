---
name: data-analytics-qc
description: QC metrics and cell/gene filtering for PBMC3k. Use when computing mitochondrial percentage, filtering low-quality cells, or writing cells_qc. For visualization use ui-viz-qc; for warehouse DDL use db-duckdb-schema.
---

# Data Analytics QC

## Defaults (PROJECT.md와 동일)

- MT genes: `gene_symbol LIKE 'MT-%'`
- Keep: `pct_counts_mt < 5 AND n_genes_by_counts >= 200 AND n_genes_by_counts < 2500`
- Gene filter after cells: expressed in ≥ 3 kept cells

## Procedure

1. DuckDB `counts` + `genes.is_mt`로 세포별 `n_genes_by_counts`, `total_counts`, `pct_counts_mt` 집계 (가능하면 순수 SQL).
2. `cells_qc.keep` 플래그 기록.
3. `cells_filtered` 갱신.
4. Gene min_cells 결과를 별도 `genes_filtered` 또는 플래그 컬럼으로 남긴다.
5. Export 스냅샷 + Astro `/qc` (`ui-viz-qc`).
6. `pipeline_runs` stage=`qc`.

## Outputs

- DuckDB: `cells_qc`, `cells_filtered`
- FE: `qc_summary.json`, `qc_cells.json` (또는 parquet)
- results: 필터 전후 세포 수 요약

scanpy `calculate_qc_metrics`를 써도 되지만 **최종 저장은 DuckDB**. pandas 중간 산출 금지.
