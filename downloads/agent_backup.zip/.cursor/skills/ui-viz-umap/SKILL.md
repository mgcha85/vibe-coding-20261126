---
name: ui-viz-umap
description: Astro UMAP scatter coloured by Leiden clusters using Apache ECharts. Use when building /umap page. For clustering backend use data-analytics-dimreduce-cluster; for ECharts rules use ui-echarts.
---

# UI Viz UMAP

**Chart library: Apache ECharts only** (`ui-echarts`).

## Chart

- ECharts `scatter` series per Leiden cluster
- Colour: Leiden → `--cluster-N`
- `large: true` for progressive rendering
- Built-in legend + tooltip (barcode, cluster, label)

## Data

`public/data/umap_points.json` — `{barcode, umap_1, umap_2, leiden, label?}`

## Rules

- Equal-ish aspect via container CSS; value axes with `scale: true` on y if needed
- No 3D UMAP; no raw SVG circle clouds
- Do not overlay promo badges on the plot
