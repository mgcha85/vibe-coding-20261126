# 챗·파일함 · 문서 형식 아이콘 (PDF / PPT / MD …)

**적용:** 챗 첨부 카드 · 내 파일함 · RAG 출처 파일 행  
**챗 연계:** `ui-chat` · `chat_ui.md` (파일 카드 영역)  
**자산:** `assets/file-types/file-*.svg`  
**구현:** 챗 파일 카드 컴포넌트 + `.chat-file-icon*` 스타일

신규 화면은 **형식별 색·약어 라벨**을 아래 표와 동일하게 쓴다. 임의 hex·이모지 📄 **금지**.

---

## 1) 형식 → 표시

| `format` (소문자) | 칩 약어 | 배경색 | SVG 자산 |
|-------------------|---------|--------|----------|
| `pdf` | PDF | `#c62828` | `file-pdf.svg` |
| `docx` | DOC | `#1565c0` | `file-docx.svg` |
| `xlsx` | XLS | `#2e7d32` | `file-xlsx.svg` |
| `pptx` | PPT | `#e65100` | `file-pptx.svg` |
| `md` | MD | `#546e7a` | `file-md.svg` |
| `mp4` | MP4 | `#6a1b9a` | `file-mp4.svg` |
| (기타) | 확장자 앞 4자 대문자 | `#455a64` | `file-default.svg` |

`markdown` 등 별칭은 매핑 함수에서 `md`로 정규화.

---

## 2) CSS 칩 (React 정본 — SVG 없이도 동일 시각)

40×40 · `border-radius: 8px` · 흰색 11px bold 약어.

```css
.chat-file-icon {
  min-width: 40px;
  height: 40px;
  border-radius: 8px;
  display: grid;
  place-items: center;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.02em;
  color: #fff;
}
.chat-file-icon-pdf { background: #c62828; }
.chat-file-icon-docx { background: #1565c0; }
.chat-file-icon-xlsx { background: #2e7d32; }
.chat-file-icon-pptx { background: #e65100; }
.chat-file-icon-md { background: #546e7a; }
.chat-file-icon-mp4 { background: #6a1b9a; }
.chat-file-icon-file { background: #455a64; }
```

클래스명: `chat-file-icon chat-file-icon-${format.toLowerCase()}` — 미등록 확장자는 `file` 또는 동적 클래스 + `chat-file-icon-file`.

---

## 3) React 마크업

```tsx
function formatIcon(format: string): string {
  const f = format.toLowerCase();
  if (f === "pdf") return "PDF";
  if (f === "docx") return "DOC";
  if (f === "xlsx") return "XLS";
  if (f === "pptx") return "PPT";
  if (f === "md" || f === "markdown") return "MD";
  if (f === "mp4") return "MP4";
  return f.slice(0, 4).toUpperCase() || "FILE";
}

<span className={`chat-file-icon chat-file-icon-${card.format.toLowerCase()}`} aria-hidden="true">
  {formatIcon(card.format)}
</span>
```

**SVG 사용 시:** `assets/file-types/`를 `public/`에 복사 후 `<img className="chat-file-icon-img" src={...} alt="" />` — 칩 크기 40×40 유지. 텍스트 칩과 **색·약어는 표와 동일**.

---

## 4) Svelte

- 동일 CSS를 `chat.css` 또는 컴포넌트 scoped style에 복사
- 또는 `{#if format === 'pdf'}<img src="/icons/file-pdf.svg" ... />{/if}` + 스킬 SVG 복사

---

## 5) 에이전트 체크리스트

- [ ] PDF/PPT/MD 등 상용 확장자가 위 표 색·약어와 일치
- [ ] 파일명은 `.chat-file-name` · 만료는 별도 muted 라벨
- [ ] `mp4`는 카드 내 `<video controls>` (챗 정본 동작)
- [ ] 아이콘 `aria-hidden` · 다운로드 링크에 `aria-label` (한국어)

---

## 6) 자산 복사 (신규 레포)

```bash
SKILL=10_skills/platform-ui/ui-governance   # Vault 경로
cp "$SKILL/assets/file-types/"*.svg frontend/public/icons/file-types/
cp "$SKILL/assets/flags/"*.svg frontend/public/icons/flags/   # 언어 슬라이더용
```

`.cursor/skills/ui-governance/assets/...` (consumer symlink)에서 동일.
