---
name: ui-governance
description: Design System/UX 원칙에 맞춰 화면 설계와 구현 결과를 검토하는 지침. 제품 UI의 SSoT. 아이콘 우선·연결 완료 collapse·패널 스크롤 등 상시 상호작용 패턴 포함.
---

# 목적
UI/UX 결과물이 Design System, Foundation, Principle을 일관되게 준수하도록 보장한다.  
**제품 UI에서는 본 스킬이 SSoT**이다.

## 언제 사용하나
- 신규 화면 설계/리뷰
- UX 품질 점검(일관성, 접근성, 단순성 등)
- 디자인 토큰/패턴 준수 검토
- 다른 UI 스킬 적용 후 **최종 게이트**

## 점검 항목
- UX Principles 준수 여부
- Color/Typo/Elevation/Layout 토큰 사용 여부
- Navigation/Page Pattern 적합성
- 해상도/브라우저 정책(PC 1920x1080 기준) 반영 여부
- 접근성 명암비 기준 충족 여부
- **기본 언어 한국어** (라벨·헬퍼·상태·인증 문구)
- **`ux_interaction_patterns.md` 상시 패턴** (아이콘 우선 · 세션 카드 액션 · SSE 진행+spinner · collapse · 패널 스크롤 · CTA 게이트 · 이력 복원)
- **챗 셸:** **`chat_shell_ui.md`** 체크리스트 (테마 아이콘만 · 계정 메뉴 · 언어 슬라이더 · 세션 rename/delete/pin · msg thumbs)
- **언어 슬라이더 · 파일 형식 칩:** **`locale_language_slider.md`** · **`file_type_icons.md`** + `assets/flags/` · `assets/file-types/`

## 운영 원칙
- 임의 컴포넌트/패턴 추가 금지
- 기존 시스템의 용어/레이블 일관성 유지
- 우선순위 정보의 시각적 위계 보장
- **기본 UI 언어 = 한국어** (`html lang="ko"`). 기술 id·URI·model명만 영문 허용

## 상시 상호작용 패턴 (요약)

상세·Do/Don't → **`ux_interaction_patterns.md`**.

| 패턴 | 한 줄 |
|---|---|
| 아이콘 우선 | 상태/연결·부수 액션은 텍스트 배지 대신 SVG 아이콘·칩 (+ `aria-label`) |
| 아이콘-only 크롬 | 테마 토글·세션 액션·msg feedback = **라벨 텍스트 없이 아이콘** |
| 완료 시 collapse | DB·LLM 등 연결/설정 폼은 성공 후 자동 접힘, 요약만 헤더 |
| 패널 스크롤 | 페이지(body) 스크롤 대신 셸 고정 + 패널/영역 내부 스크롤 |
| 헤더 얇게 | 브랜드 아래 플로우 부제 금지 |
| CTA 게이트 | 전제 미충족 시 비활성, 단계에 맞는 버튼만 활성 |
| 이력 복원 | 멀티턴이면 세션/대화 목록·선택 복원 (+ rename/delete/pin 아이콘) |
| 대기 진행 | 챗 대기 = 스트림 진행 칩 + spinner (빈 말풍선만 금지) |

## 보조 스킬과의 관계

| 보조 | 역할 | 본 스킬과의 관계 |
|---|---|---|
| `ui-chat` | 대화형 AI 챗 UI 토큰·컴포넌트 스펙 | 챗 토큰. 챗 **동작**은 `chat_ui.md` |
| `ui-design-tokens` / `ui-typography` | 앱 공통 토큰·타이포 | 챗 색·서체 기본 |

충돌 시 **본 스킬 승**. 토큰은 `ui-design-tokens`와 맞춘다.

## 참조 리소스
- **`chat_ui.md`** ← 챗 UI 정본 (세션·멘션·말풍선·**chitchat short-circuit**)
- **`chat_shell_ui.md`** ← 챗 셸 계약 (헤더·네비·테마)
- **`locale_language_slider.md`** ← 계정 메뉴 국기 + ‹ › · `assets/flags/`
- **`file_type_icons.md`** ← PDF/PPT/MD 등 · `assets/file-types/`
- `overall_guideline.md`
- `ux_foundation.md`
- `ux_design.md`
- `ux_governance.md`
- `ux_interaction_patterns.md`

챗 UI 읽기 순서: **본 SKILL → 챗이면 `chat_ui.md` → `chat_shell_ui.md` → `ux_interaction_patterns.md` → `ui-chat`**.
