# UX Foundation (발췌)

> Design System — Foundation (Elevation, Favicon, Color).  
> §1–10 Typography·Layout·Icon은 DS Figma/PDF 참조.  
> Overview → [overall_guideline.md](./overall_guideline.md) · Material Agent CSS 토큰 → [README.md](./README.md)

---

## 11. Elevation (그림자 및 계층 구조)

일반적으로 표현된 컴포넌트 계층 구조는 사용자가 컴포넌트 간의 관계를 파악할 수 있게 돕습니다. (예: Dialog가 나타날 때는 항상 모든 컴포넌트를 가리면서 나타나게 표현하여 3차원 상의 위치를 짐작하게 합니다.)

### Shadow 및 컴포넌트 Z축 기준

각 컴포넌트의 Elevation 기준에 따라 그림자 효과(Shadow)를 3가지 Depth로 적용하여 시각적 높이를 표현합니다.

| Elevation Depth | Component | 설명 및 적용 예시 |
| :--- | :--- | :--- |
| **Depth 3** | Dialog | **최상위의 Elevation** — SSO Gate, NicknamePrompt, WelcomeModal |
| **Depth 2** | Date Picker, Option List, Header Dropdown, Message Bar, Tooltip | **중간 Elevation** — UserBadge chip, step phase badge |
| **Depth 1** | Card | **최소 Elevation** — system 메시지, step 결과 카드, HelpPanel |

> **배경 Color 별 적용:** On Colored, On White, On Dark 배경에 맞추어 Depth별 그림자 스타일을 다르게 적용합니다.

**Material Agent CSS 매핑**:

| Depth | CSS 변수 | 예시 |
|-------|----------|------|
| 1 | `--shadow-sm` | 카드, 입력칩 |
| 2 | `--shadow`, `--shadow-lg` | UserBadge, 드롭다운 |
| 3 | Dialog inline `box-shadow: 0 24px 64px…` | SsoGate |

---

## 12. Favicon

Favicon은 브라우저 탭에 표기되며 시스템을 대표하는 심볼이 적용됩니다.

1. **① 엔솔이 Type (Default)** — 기본
2. **② En {시스템명} Type** — En Portal 계열
3. **③ 예외적용 Type** — 시스템 전용 심볼

> **브라우저 Tab Naming Rule:** `{시스템약어} | {시스템 Full Name}`  
> Material Agent 제안: `Material Agent`

---

## 13. Color Overview 및 접근성

Color는 시스템의 전반적인 인상을 좌우하며, 콘텐츠의 상태 및 역할을 설명하는 보조수단입니다. 한 화면 내에서 사용되는 색상의 수는 **3~5개 이내**로 제한합니다.

### Main Color

* **Primary Color**: Infinite Tiffany-Deep (`#2D9BB2`)
* **Secondary Color**: Inspiration Violet (`#554596`)
* **ES Grey**: White, Black, Grey 50/200/400 등

### Accessibility (명도 대비)

* **기본 텍스트 명암비**: `4.5 : 1` 이상
* **24px+ 또는 19px+ Bold**: `3 : 1` 이상

* **명도대비 예시:**
  * ❌ Primary `#2D9BB2` + White = **3.26 : 1** (본문 부적합)
  * 🟢 Primary 700 `#1F7795` + White = **5.08 : 1** (Button 적합)
  * 🟢 Secondary `#554596` + White = **7.87 : 1**

**Material Agent 현재**: Primary `#4f46e5` — 리브랜딩 시 DS Primary 700 또는 Secondary 적용. 상태색은 `--success`, `--warning`, `--danger` 사용.

---

## 14. Global Color

Global Token Color는 명도에 따라 Variation된 Palette를 구성합니다.

* **Main Color Palette**: Primary, Secondary, ES Grey — 50~900 단계
* **Status Color Palette**: Confirmed, Warning, Error, Done 등 5단계

---

## 15. Role Color

Global Color를 UI 요소에 목적·역할을 부여한 **Role Token Color**. Light/Dark 테마별 매칭.

### UI 요소 구분

* **Bg**: Container 배경
* **Text**: Text, Icon
* **Border**: 외곽선

### Token Name 규칙

`1차(그룹)` - `2차(UI요소)` - `3차(속성)` — 예: `Common-Bg-Basic`

### Common Colors — BG

| Role Token | Light | Dark | Material Agent (`:root`) |
|------------|-------|------|--------------------------|
| Common-Bg-Basic | Grey-White | Grey-900 | `--bg`, `--surface` |
| Common-Bg-Elevation | Grey-White | Grey-850 | `--bg-elev` |
| Common-Bg-Deep | Grey-50 | Grey-850 | `--bg` (#f6f7fb) |
| Common-Bg-Dim | #000 40% | #FFF 30% | SsoGate overlay |

### Common Colors — Text

| Role Token | Material Agent |
|------------|----------------|
| Common-Text-Basic | `--text` |
| Common-Text-Light | `--text-muted` |
| Common-Text-Lighter | `--text-faint` |
| Common-Text-Primary | `--primary` |
| Common-Text-Error | `--danger` |

### Common Colors — Border

| Role Token | Material Agent |
|------------|----------------|
| Common-Border-Basic | `--border` |
| Common-Border-Strong | `--border-strong` |

> 새 UI 작성 시 hex 하드코딩 금지 — `var(--*)` 토큰만 사용. DS 리브랜딩은 `index.css` `:root` 한 곳에서 교체.
