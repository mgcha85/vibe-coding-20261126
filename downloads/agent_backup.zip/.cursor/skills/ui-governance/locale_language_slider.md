# 계정 메뉴 · 언어 슬라이더 (국기 + ‹ ›)

**적용:** 챗 셸 계정 메뉴 · 동일 패턴이 필요한 제품 UI  
**셸 계약:** `chat_shell_ui.md` §1 (계정 메뉴)  
**자산:** `assets/flags/flag-{ko,en,zh,pl}.svg`  
**구현:** 계정 메뉴 언어 슬라이더 컴포넌트 + `.language-slider*` 토큰

에이전트·신규 프로젝트는 **별도 지시 없이** 아래 패턴·SVG·문자(‹ ›)를 그대로 쓴다. 이모지 국기·외부 CDN 국기 URL **금지**.

---

## 1) UX 패턴

| 요소 | 규칙 |
|------|------|
| 위치 | 좌측 네비 하단 **계정 메뉴** 첫 행 (`profile-row`) |
| 레이아웃 | pill 컨테이너 안 **‹ · [국기 + KO/EN/…] · ›** |
| ‹ › | 유니코드 **단일 문자** `‹` (U+2039) · `›` (U+203A). 별도 SVG chevron 불필요. `font-size: 22px`, 원형 hover (`28×28`) |
| 중앙 버튼 | 현재 locale **국기 SVG** + **2글자 locale 코드**(대문자). 클릭 시 동일 locale 재적용 가능 |
| 좌우 버튼 | 이전/다음 locale **순환** (`LANG_OPTIONS` 배열 순서) |
| a11y | 바깥 `role="radiogroup"` · `aria-label={t("common.language")}` · 좌우 `aria-label` = 이전/다음 번역 키 · 중앙 `role="radio"` `aria-checked="true"` `aria-label={locale id}` |
| 기본 locale | UI 카피 SSoT = **한국어**; 저장은 i18n / prefs API 등 레포 정책 |

**🔴 Don't:** KO/EN만 텍스트 세그먼트 · 국기 없음 · `&lt;` `&gt;` HTML 엔티티로 chevron · 외부 flag CDN.

---

## 2) 지원 locale (기본 4)

| `id` | 자산 | 비고 |
|------|------|------|
| `ko` | `assets/flags/flag-ko.svg` | 태극·괘 단순화 |
| `en` | `assets/flags/flag-en.svg` | US 단순화 (en UI) |
| `zh` | `assets/flags/flag-zh.svg` | |
| `pl` | `assets/flags/flag-pl.svg` | |

추가 언어: 동일 `viewBox="0 0 24 16"` · `class="lang-flag"` · `LANG_OPTIONS`에 한 줄 추가 + SVG 파일 추가.

---

## 3) React (인라인 SVG — 권장)

외부 요청 없이 셸에 포함. `LangFlags.tsx` 전체를 복사하거나 스킬 `assets/flags/*.svg`를 `?react` / `img`로 import.

```tsx
// AppNav.tsx — 구조만 (정본은 레포 파일)
<div className="language-slider" role="radiogroup" aria-label={t("common.language")}>
  <button type="button" className="language-slider-arrow" onClick={() => move(-1)} aria-label={t("marketplace.prev")}>‹</button>
  <button type="button" className="language-slider-current" role="radio" aria-checked="true" aria-label={option.ariaLabel}>
    {option.label}
    <span>{option.id.toUpperCase()}</span>
  </button>
  <button type="button" className="language-slider-arrow" onClick={() => move(1)} aria-label={t("marketplace.next")}>›</button>
</div>
```

`LANG_OPTIONS`: `{ id, label: <FlagXx />, ariaLabel }[]` — `LangFlags.tsx` export.

---

## 4) CSS (`tokens.css` 동일 값)

```css
.language-slider {
  display: flex;
  align-items: center;
  gap: 4px;
  width: 100%;
  padding: 3px;
  border: 1px solid var(--border);
  border-radius: 999px;
  background: var(--bg);
}
.language-slider-arrow {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  font-size: 22px;
  line-height: 1;
  border: 0;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
}
.language-slider-current {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 30px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
}
.language-slider-current .lang-flag {
  width: 24px;
  height: 16px;
}
```

---

## 5) Svelte / 정적

- `public/icons/flags/`에 스킬 SVG 복사 → `<img class="lang-flag" src="/icons/flags/flag-ko.svg" alt="" />` (`alt=""` + 부모 `aria-label`)
- 또는 SVG를 Svelte 컴포넌트로 인라인 (React `FlagFrame`과 동일 구조)

---

## 6) 검증

- E2E: 계정 메뉴 열기 → ‹ › 로 locale 변경 → UI 문자열·`html lang` 반영 (E2E: 계정 메뉴 → locale 변경 → `html lang`)
- 시각: pill 테두리 · 국기 24×16 · chevron이 세로 중앙
