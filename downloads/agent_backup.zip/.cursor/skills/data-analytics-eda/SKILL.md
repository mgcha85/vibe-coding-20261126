---
name: data-analytics-eda
description: Exploratory summary of PBMC3k raw/QC cell metrics and count matrix shape before deep QC storytelling. Use when building eda_*.json, /eda page data, or basic library-size / top-gene views. For QC thresholds use data-analytics-qc; for charts use ui-viz-eda.
---

# Data Analytics EDA

필터 **기준선 스토리**(`/qc`) 이전에, 데이터가 어떤 모양인지 보여주는 탐색 층이다.

## When

- ingest(+ `cells_qc` 지표) 이후
- export가 `eda_summary.json` / `eda_cells.json`을 씀
- Astro `/eda` (`ui-viz-eda`)

## Inputs (DuckDB)

- `cells_qc` — 세포별 `n_genes_by_counts`, `total_counts`, `pct_counts_mt`, `keep`
- `genes` — `is_mt`
- `counts` — nnz, top genes by Σcount, gene detection ladder

## Outputs

| Artifact | Content |
| --- | --- |
| `frontend/public/data/eda_summary.json` | shape, sparsity, quantiles, top genes, detection ladder |
| `frontend/public/data/eda_cells.json` | per-cell points for scatter / library-size hist |

구현: `backend/eda/build.py` → `backend.export`에서 호출. 재생성: `.venv/bin/python -m backend.eda` 또는 export.

## Metrics (required)

1. Shape: n_cells, n_genes, nnz, sparsity
2. Library size (`total_counts`) mean / median / p10 / p90
3. Genes/cell & MT% mean / median
4. Top genes by total UMI (≤20)
5. Gene detection: genes seen in ≥1 / ≥3 / ≥10 / ≥100 cells
6. Scatter fields: total_counts × n_genes_by_counts (+ keep, pct_mt)

## Rules

- DuckDB SQL primary; Polars only if awkward; **no pandas**
- FE는 DuckDB를 열지 않음 — JSON만
- `/qc`와 역할 분리: EDA=분포·형태, QC=통과/탈락 기준선
- 웹 카피에 스택명(DuckDB 등) 금지

## Related

- `ui-viz-eda` — charts
- `data-analytics-qc` — filters
- `data-analytics-export` — writes public/data
