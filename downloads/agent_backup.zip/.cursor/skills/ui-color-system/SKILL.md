---
name: ui-color-system
description: Builds accessible light-first colour roles for the lab UI and charts. Use when choosing semantic colours, contrast pairs, or categorical ramps. Adapted from Owl-Listener designer-skills color-system. For CSS variable wiring use ui-design-tokens; for chart encodings use ui-viz-*.
---

# UI Color System

Source principles: designer-skills `color-system` + `data-visualization` colour section.

## Layers

1. Brand/accent — single accent (sky/teal family), not purple default
2. Neutrals — slate scale for bg/text/border on **light** surfaces
3. Semantic — success / warning / danger / info
4. Extended — cluster categorical + sequential for expression heat

## Accessibility

- Body text on bg ≥ 4.5:1
- Large text / UI chrome ≥ 3:1
- Charts: never colour-only — pair with labels, shape, or tooltip
- Prefer colorblind-safe categorical sets (`ui-design-tokens` cluster palette)

## Light-first rule

Design tokens and pages assume white/slate-50 canvas. Dark inversion is out of scope unless user explicitly requests.
