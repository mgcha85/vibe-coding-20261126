---
name: data-analytics-dimreduce-cluster
description: Normalize, HVG, PCA, neighbors, UMAP, and Leiden clustering for PBMC3k. Use when implementing backend/cluster or changing clustering parameters. For UMAP UI use ui-viz-umap; for marker DEG use data-analytics-markers.
---

# Data Analytics Dimreduce & Cluster

수치 그래프 단계는 scanpy/igraph, **결과 표는 DuckDB**.

## Fixed params

```
seed = 0
normalize_total target_sum=1e4 → log1p
HVG flavor=seurat n_top_genes=2000
adata.raw = adata before HVG subset
scale max_value=10
pca n_comps=50
neighbors n_neighbors=15 n_pcs=30 random_state=0
umap random_state=0
leiden resolution=1.0 flavor=igraph n_iterations=2 directed=False key_added=leiden
```

`regress_out` 금지. 세포타입 라벨 부착 금지(annotate 단계).

## Procedure

1. QC 통과 세포·유전자로 AnnData 재구성 (counts from DuckDB or filtered h5ad view).
2. 위 파라미터로 파이프라인 실행.
3. Write `embeddings_umap`, `clusters`.
4. Persist run params in `pipeline_runs`.
5. Trigger export for `/umap`.

## Done when

- 모든 filtered barcode가 `clusters`와 `embeddings_umap`에 존재
- Leiden 라벨이 문자열 숫자 (`"0"`, `"1"`, …)
