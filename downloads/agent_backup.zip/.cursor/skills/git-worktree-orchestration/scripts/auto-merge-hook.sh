#!/usr/bin/env bash
# auto-merge-hook.sh (Git pre-push hook)
# Auto-merges pushes from domain worktrees (ui, data, analytics, etc.) into the main worktree.
# Location: .bare/hooks/pre-push or .git/hooks/pre-push

set -eo pipefail

# 1. Prevent infinite recursion if this hook invokes push for main
if [[ "${WORKTREE_AUTOPUSH_ACTIVE:-0}" == "1" ]]; then
  exit 0
fi

REMOTE="$1"
URL="$2"
ZERO_SHA="0000000000000000000000000000000000000000"

# Target domain branches that trigger automatic merge into main
AUTO_MERGE_BRANCHES=("ui" "data" "analytics" "auth" "db")

# Save standard input into a temporary variable or file before environment manipulation
HOOK_INPUT=$(cat)

# 2. Crucial: Clean Git environment variables exported by the calling worktree
# Git hooks inherit GIT_DIR, GIT_WORK_TREE, GIT_INDEX_FILE which would distort operations on main/
unset GIT_DIR GIT_WORK_TREE GIT_INDEX_FILE GIT_PREFIX

# 3. Find the 'main' worktree path dynamically using worktree porcelain
MAIN_DIR=""
if command -v git >/dev/null 2>&1; then
  MAIN_DIR=$(git worktree list --porcelain 2>/dev/null | awk '
    /^worktree / { wt = $2 }
    /^branch refs\/heads\/main$/ { print wt }
  ')
fi

# Fallback check if porcelain resolution was empty
if [[ -z "$MAIN_DIR" || ! -d "$MAIN_DIR" ]]; then
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd || true)"
  PARENT_DIR="$(cd "$SCRIPT_DIR/../.." 2>/dev/null && pwd || true)"
  if [[ -d "$PARENT_DIR/main" ]]; then
    MAIN_DIR="$PARENT_DIR/main"
  fi
fi

# 4. Process each pushed ref from saved hook input
while read -r local_ref local_oid remote_ref remote_oid; do
  # Skip branch deletion
  if [[ "$local_oid" == "$ZERO_SHA" || -z "$local_ref" ]]; then
    continue
  fi

  # Extract local branch name
  BRANCH_NAME="${local_ref#refs/heads/}"
  if [[ "$BRANCH_NAME" == "$local_ref" || "$BRANCH_NAME" == "main" ]]; then
    # Not a local head branch or already main, skip auto-merge
    continue
  fi

  # Check if the branch is in AUTO_MERGE_BRANCHES
  SHOULD_MERGE=0
  for target in "${AUTO_MERGE_BRANCHES[@]}"; do
    if [[ "$BRANCH_NAME" == "$target" ]]; then
      SHOULD_MERGE=1
      break
    fi
  done

  if [[ "$SHOULD_MERGE" -eq 1 ]]; then
    echo "======================================================================"
    echo "🔄 [Worktree Orchestration] Push detected on branch '$BRANCH_NAME'"
    echo "   Auto-merging '$BRANCH_NAME' -> 'main' before pushing to '$REMOTE'..."
    echo "======================================================================"

    if [[ -z "$MAIN_DIR" || ! -d "$MAIN_DIR" ]]; then
      echo "⚠️  [Worktree Orchestration] Could not locate 'main' worktree directory." >&2
      echo "   Skipping local auto-merge. Remote CI will handle merge if configured." >&2
      continue
    fi

    # Verify main worktree has no uncommitted changes
    MAIN_STATUS=$(git -C "$MAIN_DIR" status --porcelain 2>/dev/null || true)
    if [[ -n "$MAIN_STATUS" ]]; then
      echo "❌ [Worktree Orchestration] Auto-merge failed: 'main' worktree ($MAIN_DIR) has uncommitted changes!" >&2
      echo "   Please commit or stash your changes in 'main/' before pushing '$BRANCH_NAME'." >&2
      echo "   Dirty files in main/:" >&2
      echo "$MAIN_STATUS" >&2
      exit 1
    fi

    # Execute merge into main
    echo "⚙️  Merging '$BRANCH_NAME' into 'main' (at $MAIN_DIR)..."
    if ! git -C "$MAIN_DIR" merge "$BRANCH_NAME" --no-edit -m "chore(auto-merge): merge branch '$BRANCH_NAME' into main via worktree pre-push hook"; then
      echo "❌ [Worktree Orchestration] Merge conflict detected when merging '$BRANCH_NAME' into 'main'!" >&2
      echo "   Push aborted. Please navigate to '$MAIN_DIR', resolve conflicts with '$BRANCH_NAME', and commit." >&2
      git -C "$MAIN_DIR" merge --abort 2>/dev/null || true
      exit 1
    fi

    echo "✅ [Worktree Orchestration] Successfully merged '$BRANCH_NAME' into 'main'!"

    # If remote origin exists, sync main to remote
    if git -C "$MAIN_DIR" remote get-url "$REMOTE" >/dev/null 2>&1; then
      echo "🚀 [Worktree Orchestration] Pushing updated 'main' to '$REMOTE'..."
      export WORKTREE_AUTOPUSH_ACTIVE=1
      if ! git -C "$MAIN_DIR" push "$REMOTE" main; then
        echo "⚠️  [Worktree Orchestration] Warning: Failed to push 'main' to '$REMOTE'. You can push main manually." >&2
      else
        echo "✅ [Worktree Orchestration] Remote '$REMOTE/main' successfully updated."
      fi
      unset WORKTREE_AUTOPUSH_ACTIVE
    fi
  fi
done <<< "$HOOK_INPUT"

exit 0
