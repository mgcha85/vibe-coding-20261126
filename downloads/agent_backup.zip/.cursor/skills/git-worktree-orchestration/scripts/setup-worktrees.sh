#!/usr/bin/env bash
# setup-worktrees.sh
# Bootstraps a project container with a bare Git repository, 4 canonical domain worktrees (main, ui, data, analytics),
# and installs the auto-merge pre-push hook.
# Usage: ./setup-worktrees.sh [PROJECT_DIR] [ADDITIONAL_DOMAINS_CSV]

set -euo pipefail

PROJECT_DIR="${1:-.}"
EXTRA_DOMAINS="${2:-}"

# Canonical 4-domain worktrees
CANONICAL_DOMAINS=("ui" "data" "analytics")

mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"
CONTAINER_ROOT="$(pwd)"

echo "🚀 [Worktree Orchestration] Initializing 4-domain worktree architecture in $CONTAINER_ROOT..."

# Check if .bare or main already exists
if [[ -d .bare || -d main ]]; then
  echo "⚠️  Existing .bare or main/ directory detected in $CONTAINER_ROOT."
  echo "   Skipping bare initialization, ensuring domain worktrees and hooks..."
else
  # 1. Initialize bare git repository
  echo "📦 Initializing bare Git repository (.bare)..."
  git init --bare .bare
  git --git-dir=.bare symbolic-ref HEAD refs/heads/main

  # 2. Add main worktree
  echo "🌳 Creating 'main' worktree..."
  git --git-dir=.bare worktree add -b main main

  # 3. Scaffold initial main configuration if needed
  if [[ ! -f main/README.md ]]; then
    cat <<'MAIN_README' > main/README.md
# Project Main Integration Hub

This is the central integration worktree (`main/`). All domain worktree changes (`ui`, `data`, `analytics`) merge here.
Always start initial tasks, shared configs, and environment bootstrapping in this worktree.
MAIN_README
  fi

  if [[ ! -f main/WORKTREES.md ]]; then
    cat <<'WORKTREES_MD' > main/WORKTREES.md
# Worktree Domain Map

Container: `../` (Parent directory)

| Worktree | Branch | Primary Responsibility |
|:---|:---|:---|
| `main/` | `main` | Integration hub, core configs, CI/CD, default agent start |
| `ui/` | `ui` | Frontend, Svelte/Astro, Tailwind, visualization components |
| `data/` | `data` | Database schemas, DuckDB warehouse, ETL/ingest, storage |
| `analytics/` | `analytics` | Analytics pipelines, ML/algorithms, transformation stages |
WORKTREES_MD
  fi

  if [[ ! -f main/.gitignore ]]; then
    cat <<'GITIGNORE' > main/.gitignore
# Local environments & heavy dependencies
.env
.env.local
.env.*.local
node_modules/
.venv/
__pycache__/
*.pyc
*.duckdb
*.sqlite
target/
dist/
build/
GITIGNORE
  fi

  # Create initial commit in main
  (
    cd main
    git add -A
    git -c user.email="${GIT_AUTHOR_EMAIL:-agent@vibe-coding.local}" \
        -c user.name="${GIT_AUTHOR_NAME:-Worktree Orchestrator}" \
        commit -m "chore(scaffold): initial 4-domain worktree setup on main" || true
  )
fi

# 4. Create canonical domain worktrees branching from main
ALL_DOMAINS=("${CANONICAL_DOMAINS[@]}")
if [[ -n "$EXTRA_DOMAINS" ]]; then
  IFS=',' read -ra ADDS <<< "$EXTRA_DOMAINS"
  for add_d in "${ADDS[@]}"; do
    add_d="$(echo "$add_d" | xargs)"
    [[ -n "$add_d" && "$add_d" != "main" ]] && ALL_DOMAINS+=("$add_d")
  done
fi

for domain in "${ALL_DOMAINS[@]}"; do
  if [[ -d "$domain" ]]; then
    echo "ℹ️  Worktree '$domain/' already exists. Skipping creation."
    continue
  fi

  echo "🌿 Adding worktree '$domain/' on branch '$domain' (branched from main)..."
  # Check if branch exists in bare repo
  if git --git-dir=.bare rev-parse --verify "refs/heads/$domain" >/dev/null 2>&1; then
    git --git-dir=.bare worktree add "$domain" "$domain"
  else
    git --git-dir=.bare worktree add -b "$domain" "$domain" main
  fi
done

# 5. Install Git pre-push hook for automatic merging into main
echo "🪝 Installing auto-merge pre-push hook into .bare/hooks/pre-push..."
mkdir -p .bare/hooks

SCRIPT_SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd || true)"
if [[ -f "$SCRIPT_SOURCE_DIR/auto-merge-hook.sh" ]]; then
  cp "$SCRIPT_SOURCE_DIR/auto-merge-hook.sh" .bare/hooks/pre-push
else
  # Embed hook directly if source script not found
  cat <<'HOOK_EOF' > .bare/hooks/pre-push
#!/usr/bin/env bash
set -eo pipefail
if [[ "${WORKTREE_AUTOPUSH_ACTIVE:-0}" == "1" ]]; then exit 0; fi
REMOTE="$1"
ZERO_SHA="0000000000000000000000000000000000000000"
AUTO_MERGE_BRANCHES=("ui" "data" "analytics" "auth" "db")
MAIN_DIR=""
if command -v git >/dev/null 2>&1; then
  MAIN_DIR=$(git worktree list --porcelain 2>/dev/null | awk '/^worktree / { wt = $2 } /^branch refs\/heads\/main$/ { print wt }')
fi
if [[ -z "$MAIN_DIR" || ! -d "$MAIN_DIR" ]]; then
  PARENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." 2>/dev/null && pwd || true)"
  [[ -d "$PARENT_DIR/main" ]] && MAIN_DIR="$PARENT_DIR/main"
fi
while read -r local_ref local_oid remote_ref remote_oid; do
  if [[ "$local_oid" == "$ZERO_SHA" || -z "$local_ref" ]]; then continue; fi
  BRANCH_NAME="${local_ref#refs/heads/}"
  if [[ "$BRANCH_NAME" == "$local_ref" || "$BRANCH_NAME" == "main" ]]; then continue; fi
  SHOULD_MERGE=0
  for target in "${AUTO_MERGE_BRANCHES[@]}"; do
    if [[ "$BRANCH_NAME" == "$target" ]]; then SHOULD_MERGE=1; break; fi
  done
  if [[ "$SHOULD_MERGE" -eq 1 ]]; then
    echo "🔄 [Worktree Orchestration] Push detected on branch '$BRANCH_NAME'. Auto-merging -> 'main'..."
    if [[ -z "$MAIN_DIR" || ! -d "$MAIN_DIR" ]]; then
      echo "⚠️ Could not locate 'main' worktree. Skipping local merge." >&2
      continue
    fi
    if [[ -n $(git -C "$MAIN_DIR" status --porcelain 2>/dev/null) ]]; then
      echo "❌ Error: 'main' worktree ($MAIN_DIR) has uncommitted changes. Commit or stash before pushing '$BRANCH_NAME'." >&2
      exit 1
    fi
    if ! git -C "$MAIN_DIR" merge "$BRANCH_NAME" --no-edit -m "chore(auto-merge): merge branch '$BRANCH_NAME' into main via pre-push hook"; then
      echo "❌ Merge conflict occurred when merging '$BRANCH_NAME' into 'main'. Aborting push." >&2
      git -C "$MAIN_DIR" merge --abort 2>/dev/null || true
      exit 1
    fi
    echo "✅ Successfully merged '$BRANCH_NAME' into 'main'!"
    if git -C "$MAIN_DIR" remote get-url "$REMOTE" >/dev/null 2>&1; then
      export WORKTREE_AUTOPUSH_ACTIVE=1
      git -C "$MAIN_DIR" push "$REMOTE" main || echo "⚠️ Warning: Failed to push updated 'main' to '$REMOTE'." >&2
      unset WORKTREE_AUTOPUSH_ACTIVE
    fi
  fi
done
exit 0
HOOK_EOF
fi
chmod +x .bare/hooks/pre-push

# 6. Scaffold root container README.md
cat <<'CONTAINER_README' > README.md
# Worktree Container

> ⚠️ **Important**: Do not edit project code directly in this container root.  
> Work exclusively inside the designated domain worktrees below.

## Canonical Domain Worktrees

| Directory | Branch | Role |
|:---|:---|:---|
| `main/` | `main` | **Default Agent Start & Integration Hub** — shared configs, CI/CD, merge target |
| `ui/` | `ui` | **Frontend** — Svelte, Astro, Tailwind, UI components, charts |
| `data/` | `data` | **Data & Storage** — DB schemas, DuckDB warehouse, ETL pipelines |
| `analytics/` | `analytics` | **Analytics & ML** — ML models, algorithms, numerical pipelines |

## Auto-Merge Mechanism
Every `git push` executed inside `ui/`, `data/`, or `analytics/` automatically triggers the **`.bare/hooks/pre-push`** hook:
1. Validates that `main/` has a clean working tree.
2. Merges the pushed domain branch into `main/` automatically.
3. If remote tracking exists, syncs updated `main` to remote origin.

## Quick CLI Reference
```bash
# Check worktree status from anywhere
git --git-dir=.bare worktree list

# Switch to main integration worktree
cd main && git status

# Switch to UI worktree
cd ui && npm run dev
```
CONTAINER_README

# 7. Print setup summary
echo "======================================================================"
echo "🎉 4-Domain Worktree Architecture Successfully Configured!"
echo "======================================================================"
git --git-dir=.bare worktree list
echo "----------------------------------------------------------------------"
echo "📍 Rule Enforced: Always start coding in '$CONTAINER_ROOT/main'."
echo "🔄 Auto-Merge Enforced: Pushing from ui, data, or analytics will auto-merge into main."
echo "======================================================================"
