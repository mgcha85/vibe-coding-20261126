---
name: git-worktree-orchestration
description: Multi-worktree orchestration with 4 canonical domains (main, ui, data, analytics) over a bare git repository (.bare). Automatically merges domain worktree pushes into main via git pre-push hooks and GitHub Actions CI. Enforces starting in main/ and ensures parallel multi-agent isolation without branch collisions. Use when bootstrapping new projects, managing worktrees, configuring auto-merge, or coordinating multi-agent workflows.
---

# Git Worktree Orchestration (4 Canonical Domains & Auto-Merge)

**바이브 코딩 및 다중 에이전트(Multi-Agent) 병렬 협업을 위한 4대 도메인 Worktree 표준 오케스트레이션 규정**입니다.  
단일 플랫(Flat) 저장소에서 여러 에이전트가 동시에 코딩할 때 발생하는 **컨텍스트 오염, 파일 충돌(Git Thrashing), 무분별한 덮어쓰기**를 원천 차단합니다.

---

## 1. 4대 표준 Worktree 아키텍처

프로젝트 컨테이너 루트는 일반 git 체크아웃이 아닌 **`.bare` Git 데이터베이스**를 중심으로 4개의 물리적 도메인 디렉토리로 분리 구성됩니다.

```text
📁 <project-container>/              # 컨테이너 루트 (어플리케이션 코드 직접 작성 금지)
├── 🗄️ .bare/                        # 중앙 Git SSOT 객체 저장소 (Bare Repo)
│   └── hooks/
│       └── pre-push                 # 🚀 도메인 push 시 main 자동 머지 훅
├── 📄 README.md                     # 컨테이너 도메인 맵 & CLI 가이드
│
├── 🏛️ main/                         # [Branch: main] 통합 허브 & 에이전트 시작 기본점
│   ├── AGENTS.md                    # 전역 에이전트 헌법
│   ├── WORKTREES.md                 # 도메인별 소유권 및 브랜치 맵
│   ├── .github/workflows/           # CI/CD 파이프라인
│   └── ...                          # 공유 설정 및 통합 런타임
│
├── 🎨 ui/                           # [Branch: ui] 프론트엔드 전용 Worktree
│   ├── src/ (Svelte, Astro, HTML)   # UI 컴포넌트, 스타일, 시각화
│   └── package.json                 # FE 독립 의존성
│
├── 💾 data/                         # [Branch: data] 데이터 & 스토리지 Worktree
│   ├── schemas/ (DDL, SQL)          # DuckDB, SQLite, PostgreSQL 스키마
│   ├── ingest/ (ETL, 파서)          # 원시 데이터 정제 및 수집 파이프라인
│   └── warehouse/                   # 데이터베이스 파일 및 계약 정의
│
└── 📊 analytics/                    # [Branch: analytics] 분석 & ML Worktree
    ├── pipelines/ (알고리즘)        # 통계 모델, 차원축소, 군집화, 백테스트
    └── models/                      # ML 모델 및 수치 변환 파이프라인
```

### 4대 도메인 역할 및 소유권 매트릭스

| Worktree | Git Branch | 주요 역할 및 소유권 | 작업 에이전트 규칙 |
|:---|:---|:---|:---|
| **`main/`** | `main` | **통합 허브 & 초기 착수점**<br>전체 아키텍처, 공통 환경설정, CI/CD, 최종 릴리즈 | **모든 프로젝트 생성/새 스프린트 시 `main/`에서 작업 착수** |
| **`ui/`** | `ui` | **프론트엔드/시각화**<br>Svelte, Astro, Tailwind, ECharts, 반응형 레이아웃 | UI/UX 전담 에이전트 작업 공간 (BE/DB 직접 수정 금지) |
| **`data/`** | `data` | **데이터 스토리지/ETL**<br>DuckDB 스키마, SQLite 마이그레이션, 원시 데이터 수집 | Data 엔지니어링 전담 에이전트 작업 공간 |
| **`analytics/`** | `analytics` | **분석/ML/수치 파이프라인**<br>통계 알고리즘, 파이프라인 스테이지, 모델 추론 | 분석/퀀트/ML 전담 에이전트 작업 공간 |

---

## 2. Push 시 Main 자동 머지 (Auto-Merge on Push) 메커니즘

도메인 브랜치(`ui`, `data`, `analytics`)에서 작업 후 `git push`를 실행하면, **별도의 수동 PR/머지 과정 없이 즉시 `main` 브랜치로 자동 통합**되도록 2단계 안전망이 구축되어 있습니다.

```mermaid
flowchart LR
    A[Domain Worktree<br>ui / data / analytics] -->|git commit & push| B{Local Pre-Push Hook<br>.bare/hooks/pre-push}
    B -->|Check main status| C{main/ Clean?}
    C -->|Dirty| D[Push Blocked<br>main 작업 정리 요청]
    C -->|Clean| E[git merge domain -> main]
    E -->|No Conflict| F[Local main Updated]
    E -->|Conflict| G[Merge Abort &<br>Conflict Alert]
    F -->|Push origin main| H[Remote origin/main Synced]
    
    subgraph Remote Fallback
        A -.->|Remote Push| I[GitHub Actions<br>worktree-automerge.yml]
        I -->|Auto-Merge| J[GitHub origin/main]
    end
```

### 1) 로컬 Git Hook: `.bare/hooks/pre-push`
- Git Worktree 구조에서는 모든 worktree가 `.bare/hooks/`를 단일 공유합니다.
- `ui`, `data`, `analytics` 등의 브랜치 푸시가 감지되면:
  1. `main/` worktree의 작업 디렉토리가 깨끗한지(`clean`) 확인합니다.
  2. `main/` 위치로 이동하여 해당 브랜치를 즉시 merge합니다:  
     `git -C main merge <branch> --no-edit -m "chore(auto-merge): merge branch '<branch>' into main via worktree pre-push hook"`
  3. 충돌이 발생하면 즉시 `merge --abort`를 수행하고 push를 차단하여 깨진 상태가 원격으로 넘어가지 않도록 방지합니다.
  4. 머지가 성공하고 원격 저장소가 설정되어 있다면, 원격 `origin/main`으로도 자동 동기화합니다 (`WORKTREE_AUTOPUSH_ACTIVE=1`로 무한루프 방지).

### 2) 원격 CI 백업: GitHub Actions (`worktree-automerge.yml`)
- 여러 개발자나 원격 에이전트가 웹/CLI에서 직접 도메인 브랜치를 푸시한 경우, GitHub Actions가 트리거되어 원격 `main`으로 즉시 fast-forward 또는 merge 커밋을 생성합니다.

---

## 3. 원클릭 부트스트랩 스크립트 (CLI)

새로운 프로젝트를 생성할 때는 제공되는 자동화 스크립트를 실행하여 4대 worktree와 자동 머지 훅을 3초 만에 생성합니다.

### 실행 방법
```bash
# 1. 새 프로젝트 폴더에 4대 worktree 생성
./scripts/setup-worktrees.sh /path/to/new-project

# 2. 필요 시 추가 도메인(auth, db 등)과 함께 생성
./scripts/setup-worktrees.sh /path/to/new-project "auth,db"
```

### 스크립트 동작 과정
1. 대상 폴더에 `git init --bare .bare` 생성 및 `main` 심볼릭 레퍼런스 설정.
2. `main` 브랜치 기반 `main/` worktree 생성 및 기본 스캐폴드(`README.md`, `WORKTREES.md`, `.gitignore`, `AGENTS.md`) 커밋.
3. `main` 브랜치로부터 `ui/`, `data/`, `analytics/` worktree를 각각 checkout하여 배치.
4. `.bare/hooks/pre-push` 자동 머지 훅 설치 및 `chmod +x` 권한 부여.
5. 컨테이너 루트에 도메인 가이드 `README.md` 작성.

---

## 4. 에이전트 핵심 행동 수칙 (Mandatory Agent Rules)

1. **시작은 무조건 `main/`에서 (Always start in `main/`)**:
   - 프로젝트 최초 생성, 요구사항 분석(Grill-me), 전역 아키텍처 설계(`PLAN.md`), 환경설정(`.env`)은 반드시 `main/`에서 시작합니다.
2. **컨테이너 루트 오염 금지 (Do NOT edit container root)**:
   - `<project-container>/` 루트 디렉토리에는 소스 코드를 생성하지 않습니다. 코드는 반드시 `main/`, `ui/`, `data/`, `analytics/` 안에서만 작성합니다.
3. **무거운 산출물은 `main/`에만 유지 (Heavy local artifacts)**:
   - `.venv`, `node_modules`, `target/`, 대용량 DB 파일 등은 `main/`에만 설치하고, 도메인 worktree에서는 필요 시 심볼릭 링크나 경량 참조를 활용합니다.
4. **도메인 작업 후 `git push`로 자동 통합**:
   - `ui/`에서 프론트 작업을 완료하고 커밋 후 `git push origin ui`를 실행하면 자동으로 `main`에 머지됩니다.
   - 머지 충돌이 보고되면 `main/`으로 이동하여 충돌을 해결한 뒤 푸시합니다.

---

## 5. 일상 작업 치트시트

```bash
# 현재 활성화된 worktree 목록 및 브랜치 확인
git --git-dir=.bare worktree list

# UI 작업 시작
cd ui
git status
npm run dev

# UI 작업 커밋 & 푸시 (main으로 자동 머지 실행됨)
git add src/components/Header.svelte
git commit -m "feat(ui): add responsive navigation header"
git push origin ui

# 메인 통합 확인
cd ../main
git log -n 3 --oneline
```
