---
name: blueprint-chatbot
description: >-
  Chatbot build pack router — chat UI tokens, shell/session patterns, multiturn RAG,
  RAGAS eval, prompt-drift guard, optional Q&A board. Use when building or extending
  a conversational AI / chatbot / agent chat, RAG chat, SSE streaming answers,
  session list, @mention agents, or chitchat routing.
---

# Blueprint: Chatbot (통합 진입)

챗봇 구축 스킬 묶음의 라우터. 구현 시 **아래 표의 하위 스킬 `SKILL.md`를 읽는다.**

## 언제 쓰나

- 대화형 AI / RAG 챗봇을 새로 붙이거나 고칠 때
- 세션·말풍선·SSE 진행·@멘션·chitchat short-circuit·파일 첨부 챗
- 멀티턴 기억·검색 게이트·RAG 품질 평가

## 구성 (역할별)

| 층 | 스킬 | 역할 |
| --- | --- | --- |
| UI 토큰·컴포넌트 | `ui-chat` | 대화형 AI 토큰·레이아웃·말풍선·입력바 |
| UI 거버넌스·챗 동작 | `ui-governance` | UX 원칙 · `chat_ui.md` · shell · 파일칩 · 로케일 |
| 멀티턴 RAG | `blueprint-rag-multiturn` | rag-memory · Context Loader · Fast Path · Rewriter · CRAG · Memory |
| 프롬프트 드리프트 | `ai-prompt-drift-prevention` | 프롬프트/에이전트 지시 드리프트 방지 |
| RAG 품질 | `blueprint-ragas-eval` | F/AR/CR 평가 파이프라인 |
| 문의 게시판(인접) | `blueprint-qa-support-board` | 1:1 Q&A + AI 초안 (챗 UI 아님) |

## 권장 구현 순서

1. **셸·챗 UI** — `ui-governance` (`chat_shell_ui.md` → `chat_ui.md`) + `ui-chat`
2. **턴 파이프라인** — `blueprint-rag-multiturn` (chitchat Fast Path는 챗 UI 정본과 의도만 맞춤)
3. **검색·파일** — 프로젝트 knowledge/VFS 계약 (소비자 `PROJECT.md`)
4. **프롬프트** — 하드코딩 금지 시 외부 프롬프트 스토어 + `ai-prompt-drift-prevention`
5. **평가** — `blueprint-ragas-eval`

## 충돌 규칙

- 챗 **동작**(세션·멘션·말풍선·chitchat UI) → `ui-governance/chat_ui.md` 승
- 챗 **시각 토큰** → `ui-chat` (+ `ui-design-tokens` / `ui-typography`)
- 멀티턴 **기억·검색 게이트 방법론** → `blueprint-rag-multiturn` (플랫폼 중립)
- 문의 게시판 ≠ 챗봇 — `blueprint-qa-support-board`만 해당

## 말풍선 본문 (항상)

사용자 질문·AI 답변 **모두** 마크다운 + allowlist HTML 렌더.  
정본: `ui-governance/chat_ui.md` «본문 렌더링» · `ui-chat` §1.1.  
`textContent` only / 한쪽만 plain text는 회귀.

## 네이밍

`ui-*` · `blueprint-*` · `ai-*`. 본 진입 스킬: `blueprint-chatbot`.
