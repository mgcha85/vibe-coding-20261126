# Source Tree Reference

## Path constants (`backend/common/paths.py`)

```python
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA_RAW = ROOT / "data" / "raw"
DATA_WH = ROOT / "data" / "warehouse"
H5AD = DATA_RAW / "pbmc3k_raw.h5ad"
DUCKDB = DATA_WH / "pbmc3k.duckdb"
FE_DATA = ROOT / "frontend" / "public" / "data"
RESULTS = ROOT / "results"
```

## Backend stage entrypoints

각 단계는 `python -m backend.<stage>` 또는 `backend/<stage>/run.py` 중 하나로 통일한다. 기본은:

```
.venv/bin/python -m backend.ingest
.venv/bin/python -m backend.qc
.venv/bin/python -m backend.cluster
.venv/bin/python -m backend.markers
.venv/bin/python -m backend.annotate
.venv/bin/python -m backend.export
```

## Frontend routes

| Route | Data file(s) | Viz skill |
| --- | --- | --- |
| `/` | overview.json | ui-astro-app |
| `/qc` | qc_cells.parquet/json | ui-viz-qc |
| `/umap` | umap_points.json | ui-viz-umap |
| `/markers` | markers_top.json, marker_means.json | ui-viz-dotplot, ui-viz-violin |
| `/celltypes` | celltype_annotation.json | ui-astro-app |

## Import boundaries

- `frontend` → never imports `backend`
- `backend.export` → writes only under `frontend/public/data` and `results/`
- `backend.*` → may read `data/raw` read-only; write warehouse only via DuckDB connection helper
