---
name: data-analytics-source-tree
description: Defines the PBMC3k lab source tree and module ownership. Use when adding folders, moving data paths, scaffolding backend/frontend, or asking where a file belongs. For pipeline stage order use ops-pipeline-orchestration; for DuckDB tables use db-duckdb-schema.
---

# Data Analytics Source Tree

이 저장소의 디렉터리 SSOT다. 새 파일을 만들기 전에 소유 모듈을 확인한다.

## Target tree

```
src/                              # repo root
├── AGENTS.md
├── INTENT.md / PLAN.md / PROJECT.md / LESSON_AND_LEARN.md
├── prompts.md
├── data/
│   ├── raw/                      # immutable: pbmc3k_raw.h5ad, manifest.json
│   └── warehouse/                # pbmc3k.duckdb (+ optional .wal)
├── backend/
│   ├── __init__.py
│   ├── common/                   # paths, duckdb connect, seed constants
│   ├── ingest/                   # h5ad → duckdb
│   ├── qc/
│   ├── cluster/
│   ├── markers/
│   ├── annotate/
│   └── export/                   # → frontend/public/data
├── frontend/                     # Astro app
│   ├── src/pages/                # index, qc, umap, markers, celltypes, methods
│   ├── src/components/viz/
│   ├── src/assets/icons/         # nav + algo SVG (ui-chrome)
│   ├── src/styles/tokens.css
│   └── public/data/              # generated JSON/Parquet only
├── results/                      # small summaries (md/json), not matrices
├── scripts/                      # one-off CLI (prepare_data.py)
└── .cursor/skills/               # procedural memory
```

## Ownership rules

| Path | Owner skill | Writable by |
| --- | --- | --- |
| `data/raw/**` | — | human / prepare script only |
| `data/warehouse/**` | `db-*` | backend ingest/qc/cluster/markers |
| `backend/**` | `data-analytics-*` | Python stages |
| `frontend/**` | `ui-*` | Astro + viz |
| `frontend/public/data/**` | `data-analytics-export` | export job only |
| `results/**` | analytics stages | summaries |

## Do / Don't

- Do: 단계별 패키지를 `backend/<stage>/`에 둔다.
- Don't: 루트에 분석 스크립트를 난립시키거나 raw h5ad를 덮어쓴다.
- Don't: FE가 DuckDB 파일을 직접 연다. export된 `public/data`만 읽는다.

상세 경로 상수와 import 규칙은 [REFERENCE.md](REFERENCE.md).
