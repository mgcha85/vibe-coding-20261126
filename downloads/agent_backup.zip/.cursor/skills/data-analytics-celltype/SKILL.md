---
name: data-analytics-celltype
description: Infers PBMC cell-type labels from marker evidence. Use when annotating Leiden clusters or writing celltypes table / annotation markdown. Does not rerun clustering. For marker tables use data-analytics-markers.
---

# Data Analytics Celltype

코드를 재실행해 숫자를 새로 만들지 말고, DuckDB `markers` + `marker_means` + cluster sizes를 근거로 판정한다(초기 구현 시 annotate 모듈이 SQL로 읽음).

## Allowed labels (exactly one per cluster)

`CD4 T cell | CD8 T cell | B cell | CD14+ monocyte | FCGR3A+ monocyte | NK cell | Dendritic cell | Megakaryocyte / platelet | Mixed / unclear`

## Rules

- Ignore `RPS*`, `RPL*`, `MT-*` as type evidence.
- T: high `CD3D`; with high `CD8A/CD8B` → CD8 else CD4.
- B: high `MS4A1` or `CD79A`, low `CD3D`.
- Mono: high `LYZ`; CD14+S100A8 → CD14+; FCGR3A+MS4A7 high & CD14 low → FCGR3A+.
- NK: high `GNLY`+`NKG7`, low `CD3D`.
- DC: high `FCER1A`+`CST3`, low `MS4A1`.
- Platelet: high `PPBP`.
- Do not force T/B/mono if markers disagree → Mixed / unclear.
- Do not memorize textbook cluster IDs; cite warehouse numbers only.

## Outputs

- DuckDB `celltypes`
- `results/celltype_annotation.md` + FE JSON
