# AGENTS.md

PBMC 3k scRNA-seq 바이브 코딩 실습 저장소의 Every-turn 헌법이다. 모호하면 코딩 전에 역질문한다.

## 1) Mission & Scope

- 목표: 10x PBMC 3k를 **DuckDB 웨어하우스 → 분석 파이프라인 → Astro 시각화**까지 재현 가능한 연구 앱으로 구축한다.
- 범위: QC → 차원축소/군집 → 마커 → 세포타입 추론 → Astro 대시보드.
- 범위 밖: 클라우드 배포, 다중 샘플 통합, 새 원시 데이터 다운로드(이미 `data/raw/`에 있음).

## 2) Stack (강제)

| 층 | 기술 | 규칙 |
| --- | --- | --- |
| BE | Python 3.12 + `.venv` | `uv`로 패키지 설치 |
| Warehouse | **DuckDB (주력)** | 테이블·집계·내보내기의 SSOT |
| Frame | **Polars (보조)** | SQL로 어색한 변환만. `import pandas` **금지** |
| Graph ML | scanpy / numpy / scipy / igraph | PCA·neighbors·UMAP·Leiden·rank_genes_groups만 |
| FE | **Astro** | 모든 단계 시각화는 Astro 페이지/컴포넌트 |
| Charts | **Apache ECharts** | `frontend/src/lib/echarts-setup.ts` + `ui-viz-*`. 손수 SVG/타 차트 라이브러리 금지 |
| Methods explain | `/methods` | HTML 보드(누가/무엇을, 데이터 흐름) + 단계 스키매틱 + 세포 퍼널 + 실행 타임라인 (`ui-methods-explain`). **웹 카피에 C4 레벨명·스택명(DuckDB/Astro/ECharts 등) 금지** |
| UI | light background 기본 | `.cursor/skills/ui-*` 준수 |

금지: `pandas`, Jupyter를 최종 산출물로 사용, matplotlib/seaborn PNG·손수 SVG를 Astro 차트 대체로 사용(디버그 PNG는 `results/`만).

## 3) Directory Ownership

```
data/raw/                 # 읽기 전용 원본 (h5ad). 수정 금지
data/warehouse/           # DuckDB 파일만. BE ingest/분석이 소유
backend/                  # Python 파이프라인 단계 모듈
frontend/                 # Astro 앱. 시각화 SSOT
frontend/public/data/     # DuckDB export JSON/Parquet (생성물)
results/                  # 요약 md/json. 대용량 행렬 금지
.cursor/skills/           # 절차 기억 SSOT (.agents/.opencode는 심볼릭 링크)
```

상세 트리는 스킬 `data-analytics-source-tree`를 읽는다.

## 4) Pipeline Order (절대 순서)

1. `db-ingest-h5ad` — h5ad → DuckDB
2. `data-analytics-eda` — 기본 EDA + `ui-viz-eda` (`/eda`; QC 지표 테이블 이후)
3. `data-analytics-qc` — QC 필터 + `ui-viz-qc`
4. `data-analytics-dimreduce-cluster` — PCA/UMAP/Leiden + `ui-viz-umap`
5. `data-analytics-markers` — DEG + `ui-viz-dotplot` / `ui-viz-violin`
6. `data-analytics-celltype` — 마커 기반 타입 추론
7. `data-analytics-export` — Astro용 아티팩트 갱신

앞 단계 산출물 없이 뒷 단계를 구현하지 않는다. 오케스트레이션은 `ops-pipeline-orchestration`.

## 5) Context Load Order

코드 수정 전:

1. `AGENTS.md` (본 문서)
2. `INTENT.md` → `PLAN.md` → `PROJECT.md`
3. 관련 `.cursor/skills/<name>/SKILL.md` (필요 시 `REFERENCE.md`)
4. `LESSON_AND_LEARN.md`
5. 대상 모듈 소스

## 6) Grill-me

요구가 모호하면 구현 전 3~5개만 묻는다. 예: 어느 파이프라인 단계인지, 새 DuckDB 테이블인지 export 갱신인지, Astro 라우트 추가인지.

## 7) Quality Gates

```bash
.venv/bin/python -c "import pandas"  # 반드시 ImportError
.venv/bin/ruff check backend/
cd frontend && npm run build
```

커밋은 사용자 요청 시에만. `.env` 시크릿 커밋 금지. `rm -rf`, `DROP TABLE`/`DROP DATABASE` 파괴 명령 금지(명시 요청 제외).

## 8) Data Contract

- 원본: `data/raw/pbmc3k_raw.h5ad` (2700 × 32738, raw count, hg19)
- Warehouse: `data/warehouse/pbmc3k.duckdb`
- 스키마: 스킬 `db-duckdb-schema`
- 시드: 분석 난수 `random_state=0` / `sc.settings.seed = 0`
- QC 기본: `pct_counts_mt < 5` AND `200 <= n_genes_by_counts < 2500`

## 9) Skills Index

| Prefix | Skills |
| --- | --- |
| `data-analytics-*` | `source-tree`, `eda`, `qc`, `dimreduce-cluster`, `markers`, `celltype`, `export` |
| `db-*` | `duckdb-schema`, `ingest-h5ad`, `query-patterns` |
| `ui-*` | `echarts`, `methods-explain`, `chrome`, `astro-app`, `design-tokens`, `color-system`, `typography`, `layout-grid`, `viz-eda`, `viz-qc`, `viz-umap`, `viz-dotplot`, `viz-violin` |
| `ops-*` | `pipeline-orchestration` |

## 10) Session Recovery

세션이 바뀌면 `PLAN.md`의 미완료 체크부터 이어간다. 새 교훈은 `LESSON_AND_LEARN.md`에 증상/원인/해결/교훈 4줄로 추가한다.
