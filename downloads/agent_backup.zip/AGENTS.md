# AGENTS.md

프로젝트 특화(스택·데이터·포트·게이트 커맨드)는 `PROJECT.md`에 둔다. 모호하면 코딩 전에 역질문한다.

## 0) 문서 역할

| 문서 | 역할 |
| --- | --- |
| `AGENTS.md` | 공통 규칙, 컨텍스트 로드, 스킬 인덱스 (본 문서) |
| `INTENT.md` | 왜 / 누구 / 수락 기준 / 비목표 |
| `PLAN.md` | 세션 체크리스트·진행 상태 |
| `PROJECT.md` | 미션·스택·경로·파이프라인·데이터 계약·품질 게이트 |
| `LESSON_AND_LEARN.md` | 시행착오 (증상/원인/해결/교훈) |
| `ADR.md` / `ROADMAP.md` | 있으면 결정·로드맵 (없으면 만들지 않음) |

절차·단계 실행은 `.cursor/skills/`가 SSOT다. `CLAUDE.md`는 만들지 않는다 (AGENTS와 중복).

## 1) Context Load Order

코드 수정 전:

1. `AGENTS.md` (본 문서)
2. `INTENT.md` → `PLAN.md` → `PROJECT.md`
3. 관련 `.cursor/skills/<name>/SKILL.md` (필요 시 `REFERENCE.md`)
4. `LESSON_AND_LEARN.md`
5. 대상 모듈 소스

## 2) 공통 코딩/운영 규칙

- 요구가 모호하면 구현하지 말고 Grill-me한다.
- 커밋·푸시는 사용자 요청 시에만.
- `.env` 및 시크릿을 커밋하지 않는다.
- `rm -rf`, `DROP TABLE` / `DROP DATABASE` 등 파괴 명령은 명시 요청 없이 금지.
- 프로젝트 품질 게이트 커맨드는 `PROJECT.md`를 따른다.
- 새 스킬·에이전트·운영 규칙이 생기면 `harness-agents-md` 기준으로 본 문서를 갱신한다.

## 3) Grill-me

구현 전 3~5개만 묻는다. 예: 어느 파이프라인/모듈 단계인지, 어느 경로·산출물을 건드리는지, 새 라우트/테이블/문서인지, 범위 밖 요청인지.

## 4) Custom Agents

(없음)

## 5) Agent Skills

`.cursor/skills/` flat 목록. `.cursor/skills-unused/`는 제외.

| Prefix | Skills |
| --- | --- |
| `data-analytics-*` | `source-tree`, `eda`, `qc`, `dimreduce-cluster`, `markers`, `celltype`, `export` |
| `db-*` | `duckdb-schema`, `ingest-h5ad`, `query-patterns` |
| `ui-*` | `echarts`, `methods-explain`, `chrome`, `astro-app`, `design-tokens`, `color-system`, `typography`, `layout-grid`, `viz-eda`, `viz-qc`, `viz-umap`, `viz-dotplot`, `viz-violin` |
| `ops-*` | `pipeline-orchestration` |
| (agent style) | `ponytail`, `ponytail-audit`, `ponytail-debt`, `ponytail-gain`, `ponytail-help`, `ponytail-review`, `i-have-adhd` |
| (knowledge graph) | `graphify` |

## 6) 선택 규칙

| 상황 | 읽을 곳 |
| --- | --- |
| 폴더 추가·경로·소유권 | `data-analytics-source-tree` |
| 파이프라인 단계 순서 | `ops-pipeline-orchestration` + `PROJECT.md` |
| 웨어하우스 스키마·쿼리 | `db-*` |
| 차트·페이지·크롬 | `ui-*` |
| 스택·데이터 계약·로컬 URL·게이트 | `PROJECT.md` |
| 최소 변경·YAGNI | `ponytail` (+ audit/review/debt/gain/help) |
| ADHD-friendly 출력 (액션 먼저) | `i-have-adhd` |
| 코드베이스 지식 그래프·경로 질의 | `graphify` (`/graphify .`로 빌드) |

## 7) Session Recovery

세션이 바뀌면 `PLAN.md`의 미완료 체크부터 이어간다. 새 교훈은 `LESSON_AND_LEARN.md`에 증상/원인/해결/교훈 4줄로 추가한다.
